# Importando as biliotecas e informações de outros arquivos
from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as login_django
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import smart_bytes
from django.utils.http import urlsafe_base64_encode
from django.core.mail import send_mail
from django.urls import reverse
from django.shortcuts import render
from django.contrib.auth.models import User
# views.py
from .models import Usuario, Categoria

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render
from .models import Usuario


import os
from PIL import Image
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from AtlaS.models import Usuario  # Certifique-se de usar o modelo correto
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
from PIL import Image
import os
import re
from .models import Usuario, Categoria

@csrf_exempt
def cadastro(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        email = request.POST['email']
        senha = request.POST['senha']
        telefone = request.POST['telefone']
        imagem = request.FILES.get('imagem')
        id_categoria = request.POST.get('id_categoria')

        # Validação de email já registrado
        if Usuario.objects.filter(email=email).exists():
            messages.error(request, 'E-mail já cadastrado. Por favor, use outro.')
            return redirect('cadastro')

        # Validação de telefone já registrado
        if Usuario.objects.filter(telefone=telefone).exists():
            messages.error(request, 'Número de telefone já vinculado a outro usuário.')
            return redirect('cadastro')

        # Validação de senha forte
        if len(senha) < 8 or not re.search(r'[A-Za-z]', senha) or not re.search(r'\d', senha):
            messages.error(
                request,
                'A senha deve conter pelo menos 8 caracteres, incluindo letras e números.'
            )
            return redirect('cadastro')

        try:
            categoria = Categoria.objects.get(id_categoria=int(id_categoria))
        except Categoria.DoesNotExist:
            messages.error(request, 'Categoria não encontrada.')
            return redirect('cadastro')

        senha_criptografada = make_password(senha)

        usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha_criptografada,
            telefone=telefone,
            id_categoria=categoria
        )
        usuario.save()

        if imagem:
            pasta_fotos = os.path.join('AtlaS', 'static', 'AtlaS', 'images', 'media', 'fotos_de_perfil')
            os.makedirs(pasta_fotos, exist_ok=True)

            img = Image.open(imagem)
            img = img.resize((500, 500), Image.LANCZOS)

            primeiro_nome = nome.split()[0].capitalize()
            novo_nome = f"{primeiro_nome}{usuario.id_user}.png"
            caminho_completo = os.path.join(pasta_fotos, novo_nome)

            img.save(caminho_completo)

            usuario.imagem = f'AtlaS/images/media/fotos_de_perfil/{novo_nome}'
            usuario.save()

        messages.success(request, 'Usuário cadastrado com sucesso!')
        return redirect('login')

    return render(request, 'cadastro.html')

from django.contrib.auth.hashers import check_password
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth import get_backends
from AtlaS.models import Usuario

@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        
        try:
            # Busca o usuário pelo email
            usuario = Usuario.objects.get(email=email)
            
            # Verifica a senha fornecida com a senha criptografada
            if check_password(senha, usuario.senha):
                # Define o backend manualmente no usuário
                backend = get_backends()[0]  # Usa o primeiro backend na lista de backends configurados
                usuario.backend = f"{backend.__module__}.{backend.__class__.__name__}"
                
                # Faz o login do usuário autenticado
                login(request, usuario)
                return redirect('inicio')
            else:
                return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
        
        except Usuario.DoesNotExist:
            return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
    
    return render(request, 'login.html')



import os
import base64
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import smart_bytes
from django.conf import settings
from django.contrib.auth.tokens import default_token_generator
from django.urls import reverse
from django.shortcuts import render
from django.utils.timezone import now
from .models import Usuario  # Ajuste o import do modelo de usuário, se necessário

def send_password_reset_email(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            # Verifica se o usuário existe
            user = Usuario.objects.get(email=email)
            
            # Gera o token e o UID codificado
            token = default_token_generator.make_token(user)
            uidb64 = urlsafe_base64_encode(smart_bytes(user.pk))

            # Gera o link de redefinição de senha
            reset_link = request.build_absolute_uri(reverse('password_reset_confirm', args=[uidb64, token]))

            # Formata o conteúdo do e-mail
            subject = 'Password Reset Request'
            from_email = 'your_email@example.com'
            to_email = email
            date = now().strftime('%a, %d %b %Y %H:%M:%S -0000')
            message_id = f"<{base64.urlsafe_b64encode(os.urandom(16)).decode()}@{settings.ALLOWED_HOSTS[0] if settings.ALLOWED_HOSTS else 'localhost'}>"

            message = f"""\
Content-Type: text/plain; charset="utf-8"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Subject: {subject}
From: {from_email}
To: {to_email}
Date: {date}
Message-ID: {message_id}

Click on the link to reset your password: {reset_link}
-------------------------------------------------------------------------------
"""

            # Salva o e-mail simulado em um arquivo de texto
            sent_emails_dir = os.path.join(settings.BASE_DIR, 'Sent_Emails')
            if not os.path.exists(sent_emails_dir):
                os.makedirs(sent_emails_dir)

            file_path = os.path.join(sent_emails_dir, f'password_reset_{user.pk}.txt')
            with open(file_path, 'w', encoding='utf-8') as email_file:
                email_file.write(message)

            # Passa a mensagem de sucesso para o template
            success_message = f'E-mail simulado enviado com sucesso! Verifique o arquivo em: {file_path}.'
            return render(request, 'login.html', {'email': email, 'success_message': success_message})

        except Usuario.DoesNotExist:
            # Passa mensagem de erro para o template
            return render(request, 'login.html', {'error_message': 'Usuário não encontrado com esse email!'})

    else:
        return render(request, 'login.html')


def reset_password(request):
    return render(request, 'reset_password.html')




# AtlaS/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.hashers import make_password
from .models import Usuario


# Função personalizada para verificar se o usuário está autenticado
def usuario_autenticado(request):
    return 'usuario_id' in request.session



from .models import Cursos
from datetime import datetime
from django.shortcuts import render, redirect
from django.utils import timezone
import mysql.connector
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
import mysql.connector
from .models import Cursos
import json
import json
import mysql.connector
from django.shortcuts import render
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from .models import Cursos

@login_required(login_url='login')
def formulario(request):

    reserved_days_list = []  # Inicializa a lista para armazenar os dias reservados

        # Conexão com o banco de dados
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="devmysql",
        database="AtlaS"
    )
    cursor = db.cursor()

    # Pesquisa 1: id_periodo = 1 (antes do intervalo) e id_turno = 1 (manhã)
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 2: id_periodo = 1 (antes do intervalo) e id_turno = 2 (tarde)
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 3: id_periodo = 2 (após o intervalo) e id_turno = 1 (manhã)
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 4: id_periodo = 2 (após o intervalo) e id_turno = 2 (tarde)
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

   # Pesquisa 1 do auditório
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 1 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    auditorio_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 2 do auditório
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 1 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    auditorio_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 3 do auditório
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 1 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    auditorio_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    # Pesquisa 4 do auditório
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 1 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    auditorio_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Biblioteca
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 2 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    biblioteca_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 2 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    biblioteca_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 2 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    biblioteca_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 2 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    biblioteca_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Oficina de Automobilística
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 3 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaAutomobilistica_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 3 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaAutomobilistica_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 3 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaAutomobilistica_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 3 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaAutomobilistica_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Oficina de Costura
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 4 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaCostura_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 4 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaCostura_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 4 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaCostura_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 4 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaCostura_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Metrologia
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 5 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioMetrologia_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 5 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioMetrologia_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 5 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioMetrologia_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 5 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioMetrologia_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Automoção Residencial
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 6 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioAutonomoResidencial_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 6 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioAutonomoResidencial_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 6 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioAutonomoResidencial_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 6 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioAutonomoResidencial_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala de Solda
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 7 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    salaSolda_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 7 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    salaSolda_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 7 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    salaSolda_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 7 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    salaSolda_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Oficina de Usinagem
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 8 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaUsinagem_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 8 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaUsinagem_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 8 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficinaUsinagem_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 8 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficinaUsinagem_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Redes - TI
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 9 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioRedesTI_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 9 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioRedesTI_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 9 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorioRedesTI_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 9 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorioRedesTI_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala C1
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 10 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    salaC1_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 10 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    salaC1_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 10 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    salaC1_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 10 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    salaC1_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala C2
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 11 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c2_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 11 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c2_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 11 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c2_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 11 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c2_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala C3
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 12 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c3_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 12 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c3_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 12 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c3_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 12 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c3_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Administração
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 13 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_administracao_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 13 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_administracao_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 13 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_administracao_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 13 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_administracao_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala C5
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 14 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c5_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 14 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c5_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 14 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_c5_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 14 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_c5_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório CAD
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_cad_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_cad_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_cad_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_cad_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório CAM
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_cam_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_cam_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_cam_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 15 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_cam_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório TI 1
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 16 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_1_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 16 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_1_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 16 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_1_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 16 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_1_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório TI 2
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 17 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_2_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 17 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_2_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 17 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_2_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 17 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_2_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório TI 3
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 18 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_3_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 18 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_3_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 18 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_3_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 18 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_3_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório TI 4
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 19 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_4_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 19 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_4_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 19 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_ti_4_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 19 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_ti_4_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Hidráulica
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 20 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_Hidraulica_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 20 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_Hidraulica_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 20 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_Hidraulica_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 20 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_Hidraulica_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Sala CLP
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 21 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_clp_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 21 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_clp_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 21 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    sala_clp_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 21 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    sala_clp_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Eletroeletrônica
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 22 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_Eletroeletronica_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 22 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_Eletroeletronica_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 22 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_Eletroeletronica_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 22 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_Eletroeletronica_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Laboratório de Máquina e Comandos
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 23 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_maquina_comandos_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 23 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_maquina_comandos_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 23 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    laboratorio_maquina_comandos_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 23 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    laboratorio_maquina_comandos_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Oficina Elétrica 1
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 24 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficina_eletrica_1_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 24 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficina_eletrica_1_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 24 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficina_eletrica_1_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 24 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficina_eletrica_1_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]

    # Oficina Elétrica 2
    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 25 AND id_periodo_id = 1 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficina_eletrica_2_booked_days_period1_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 25 AND id_periodo_id = 1 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficina_eletrica_2_booked_days_period1_turn2 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 25 AND id_periodo_id = 2 AND id_turno_id = 1 AND id_status_id = 2
    """)
    oficina_eletrica_2_booked_days_period2_turn1 = [str(day[0]) for day in cursor.fetchall()]

    cursor.execute("""
        SELECT reserved_day
        FROM reservas
        WHERE id_room_id = 25 AND id_periodo_id = 2 AND id_turno_id = 2 AND id_status_id = 2
    """)
    oficina_eletrica_2_booked_days_period2_turn2 = [str(day[0]) for day in cursor.fetchall()]


    # Verifica se a requisição é do tipo POST
    if request.method == 'POST':
        selected_dates = request.POST.get('selectedDates', '')  # Obtém as datas selecionadas do formulário
        reserved_days_list = selected_dates.split(',') if selected_dates else []  # Divide as datas selecionadas
        
        if not reserved_days_list:  # Caso não haja datas selecionadas
            print("Nenhuma data reservada selecionada.")
            return render(request, 'formulario.html', {
                'cursos': Cursos.objects.filter(status_curso=True),  # Envia os cursos ativos para o template
                'alert_message': 'Por favor, selecione pelo menos um dia para reserva.',
                'reserved_days_list': json.dumps([]),  # Passa uma lista vazia para o JavaScript
                'all_booked_days': json.dumps([]),  # Passa uma lista vazia de datas reservadas
            })
        print(reserved_days_list)
        
        # Obter o nome da sala e mapear para o ID correspondente
        id_curso = request.POST.get('id_curso')
        course_name = request.POST.get('course-name')
        room_mapping = {
            "Auditório": 1,
            "Biblioteca": 2,
            "Oficina de Automobilística": 3,
            "Oficina de Costura": 4,
            "Laboratório de Metrologia": 5,
            "Laboratório de Automoção Residencial": 6,
            "Sala de Solda": 7,
            "Oficina de Usinagem": 8,
            "Laboratório de Redes - TI": 9,
            "Sala C1": 10,
            "Sala C2": 11,
            "Sala C3": 12,
            "Laboratório de Administração": 13,
            "Sala C5": 14,
            "Laboratório CAD": 15,
            "Laboratório CAM": 16,
            "Laboratório TI 1": 17,
            "Laboratório TI 2": 18,
            "Laboratório TI 3": 19,
            "Laboratório TI 4": 20,
            "Laboratório de Hidráulica": 21,
            "Sala CLP": 22,
            "Laboratório de Eletroeletrônica": 23,
            "Laboratório de Máquina e Comandos": 24,
            "Oficina Elétrica 1": 25,
            "Oficina Elétrica 2": 26,
        }
        room_python = room_mapping.get(course_name, None)

        # Definir turno e período
        turno_python = 1 if request.POST.get('turn') == 'antes' else 2
        periodo_python = 1 if request.POST.get('period') == 'antes' else 2
        
        # Dados do usuário e horário atual
        newuser_python = request.user.id_user
        current_python_datetime = timezone.now()


        # Atualiza os dias reservados no banco de dados
        if reserved_days_list:
            placeholders = ', '.join(['%s'] * len(reserved_days_list))
            update_query = f"""
                UPDATE reservas
                SET
                    id_curso_id = %s,
                    id_room_id = %s,
                    id_turno_id = %s,
                    id_periodo_id = %s,
                    id_user_id = %s,
                    reserve_time = %s,
                    id_status_id = 2
                WHERE
                    id_room_id = %s AND
                    id_turno_id = %s AND
                    id_periodo_id = %s AND
                    id_status_id = 1 AND
                    reserved_day IN ({placeholders})
            """
            
            # Parâmetros para a consulta de atualização
            params = (
                id_curso, room_python, turno_python, periodo_python,
                newuser_python, current_python_datetime,
                room_python, turno_python, periodo_python,
            ) + tuple(reserved_days_list)

            try:
                cursor.execute(update_query, params)
                db.commit()
                print(f"{cursor.rowcount} registro(s) atualizado(s) com sucesso.")
                return redirect('reservas')  # 'reservas' é o nome da URL configurada para a view de reservas
            except mysql.connector.Error as e:
                print(f"Erro ao atualizar a tabela: {e}")
                print("Consulta que causou o erro:", cursor.statement)
            finally:
                cursor.close()
                db.close()

    # Renderiza o formulário se não for um POST ou após o POST
    cursos = Cursos.objects.filter(status_curso=True)  # Filtra apenas os cursos com status ativo
    return render(request, 'formulario.html', {
    'cursos': cursos,
    'alert_message': '',  # Se não houver mensagem de alerta
    'reserved_days_list': json.dumps(reserved_days_list),  # Passa a lista de dias reservados para o JavaScript
    'booked_days_period1_turn1': json.dumps(booked_days_period1_turn1),
    'booked_days_period1_turn2': json.dumps(booked_days_period1_turn2),
    'booked_days_period2_turn1': json.dumps(booked_days_period2_turn1),
    'booked_days_period2_turn2': json.dumps(booked_days_period2_turn2),

    'auditorio_booked_days_period1_turn1': json.dumps(auditorio_booked_days_period1_turn1),
    'auditorio_booked_days_period1_turn2': json.dumps(auditorio_booked_days_period1_turn2),
    'auditorio_booked_days_period2_turn1': json.dumps(auditorio_booked_days_period2_turn1),
    'auditorio_booked_days_period2_turn2': json.dumps(auditorio_booked_days_period2_turn2),
    
    'biblioteca_booked_days_period1_turn1': json.dumps(biblioteca_booked_days_period1_turn1),
    'biblioteca_booked_days_period1_turn2': json.dumps(biblioteca_booked_days_period1_turn2),
    'biblioteca_booked_days_period2_turn1': json.dumps(biblioteca_booked_days_period2_turn1),
    'biblioteca_booked_days_period2_turn2': json.dumps(biblioteca_booked_days_period2_turn2),
    
    'oficinaAutomobilistica_booked_days_period1_turn1': json.dumps(oficinaAutomobilistica_booked_days_period1_turn1),
    'oficinaAutomobilistica_booked_days_period1_turn2': json.dumps(oficinaAutomobilistica_booked_days_period1_turn2),
    'oficinaAutomobilistica_booked_days_period2_turn1': json.dumps(oficinaAutomobilistica_booked_days_period2_turn1),
    'oficinaAutomobilistica_booked_days_period2_turn2': json.dumps(oficinaAutomobilistica_booked_days_period2_turn2),
    
    'oficinaCostura_booked_days_period1_turn1': json.dumps(oficinaCostura_booked_days_period1_turn1),
    'oficinaCostura_booked_days_period1_turn2': json.dumps(oficinaCostura_booked_days_period1_turn2),
    'oficinaCostura_booked_days_period2_turn1': json.dumps(oficinaCostura_booked_days_period2_turn1),
    'oficinaCostura_booked_days_period2_turn2': json.dumps(oficinaCostura_booked_days_period2_turn2),
    
    'laboratorioMetrologia_booked_days_period1_turn1': json.dumps(laboratorioMetrologia_booked_days_period1_turn1),
    'laboratorioMetrologia_booked_days_period1_turn2': json.dumps(laboratorioMetrologia_booked_days_period1_turn2),
    'laboratorioMetrologia_booked_days_period2_turn1': json.dumps(laboratorioMetrologia_booked_days_period2_turn1),
    'laboratorioMetrologia_booked_days_period2_turn2': json.dumps(laboratorioMetrologia_booked_days_period2_turn2),
    
    'laboratorioAutomoçãoResidencial_booked_days_period1_turn1': json.dumps(laboratorioAutonomoResidencial_booked_days_period1_turn1),
    'laboratorioAutomoçãoResidencial_booked_days_period1_turn2': json.dumps(laboratorioAutonomoResidencial_booked_days_period1_turn2),
    'laboratorioAutomoçãoResidencial_booked_days_period2_turn1': json.dumps(laboratorioAutonomoResidencial_booked_days_period2_turn1),
    'laboratorioAutomoçãoResidencial_booked_days_period2_turn2': json.dumps(laboratorioAutonomoResidencial_booked_days_period2_turn2),
    
    'salaSolda_booked_days_period1_turn1': json.dumps(salaSolda_booked_days_period1_turn1),
    'salaSolda_booked_days_period1_turn2': json.dumps(salaSolda_booked_days_period1_turn2),
    'salaSolda_booked_days_period2_turn1': json.dumps(salaSolda_booked_days_period2_turn1),
    'salaSolda_booked_days_period2_turn2': json.dumps(salaSolda_booked_days_period2_turn2),
    
    'oficinaUsinagem_booked_days_period1_turn1': json.dumps(oficinaUsinagem_booked_days_period1_turn1),
    'oficinaUsinagem_booked_days_period1_turn2': json.dumps(oficinaUsinagem_booked_days_period1_turn2),
    'oficinaUsinagem_booked_days_period2_turn1': json.dumps(oficinaUsinagem_booked_days_period2_turn1),
    'oficinaUsinagem_booked_days_period2_turn2': json.dumps(oficinaUsinagem_booked_days_period2_turn2),
    
    'laboratorioRedesTI_booked_days_period1_turn1': json.dumps(laboratorioRedesTI_booked_days_period1_turn1),
    'laboratorioRedesTI_booked_days_period1_turn2': json.dumps(laboratorioRedesTI_booked_days_period1_turn2),
    'laboratorioRedesTI_booked_days_period2_turn1': json.dumps(laboratorioRedesTI_booked_days_period2_turn1),
    'laboratorioRedesTI_booked_days_period2_turn2': json.dumps(laboratorioRedesTI_booked_days_period2_turn2),
    
    'salaC1_booked_days_period1_turn1': json.dumps(salaC1_booked_days_period1_turn1),
    'salaC1_booked_days_period1_turn2': json.dumps(salaC1_booked_days_period1_turn2),
    'salaC1_booked_days_period2_turn1': json.dumps(salaC1_booked_days_period2_turn1),
    'salaC1_booked_days_period2_turn2': json.dumps(salaC1_booked_days_period2_turn2),
    
    'sala_c2_booked_days_period1_turn1': json.dumps(sala_c2_booked_days_period1_turn1),
    'sala_c2_booked_days_period1_turn2': json.dumps(sala_c2_booked_days_period1_turn2),
    'sala_c2_booked_days_period2_turn1': json.dumps(sala_c2_booked_days_period2_turn1),
    'sala_c2_booked_days_period2_turn2': json.dumps(sala_c2_booked_days_period2_turn2),
    
    'sala_c3_booked_days_period1_turn1': json.dumps(sala_c3_booked_days_period1_turn1),
    'sala_c3_booked_days_period1_turn2': json.dumps(sala_c3_booked_days_period1_turn2),
    'sala_c3_booked_days_period2_turn1': json.dumps(sala_c3_booked_days_period2_turn1),
    'sala_c3_booked_days_period2_turn2': json.dumps(sala_c3_booked_days_period2_turn2),
    
    'laboratorio_administracao_booked_days_period1_turn1': json.dumps(laboratorio_administracao_booked_days_period1_turn1),
    'laboratorio_administracao_booked_days_period1_turn2': json.dumps(laboratorio_administracao_booked_days_period1_turn2),
    'laboratorio_administracao_booked_days_period2_turn1': json.dumps(laboratorio_administracao_booked_days_period2_turn1),
    'laboratorio_administracao_booked_days_period2_turn2': json.dumps(laboratorio_administracao_booked_days_period2_turn2),
    
    'sala_c5_booked_days_period1_turn1': json.dumps(sala_c5_booked_days_period1_turn1),
    'sala_c5_booked_days_period1_turn2': json.dumps(sala_c5_booked_days_period1_turn2),
    'sala_c5_booked_days_period2_turn1': json.dumps(sala_c5_booked_days_period2_turn1),
    'sala_c5_booked_days_period2_turn2': json.dumps(sala_c5_booked_days_period2_turn2),
    
    'laboratorio_cad_booked_days_period1_turn1': json.dumps(laboratorio_cad_booked_days_period1_turn1),
    'laboratorio_cad_booked_days_period1_turn2': json.dumps(laboratorio_cad_booked_days_period1_turn2),
    'laboratorio_cad_booked_days_period2_turn1': json.dumps(laboratorio_cad_booked_days_period2_turn1),
    'laboratorio_cad_booked_days_period2_turn2': json.dumps(laboratorio_cad_booked_days_period2_turn2),
 
    'laboratorio_cam_booked_days_period1_turn1': json.dumps(laboratorio_cam_booked_days_period1_turn1),
    'laboratorio_cam_booked_days_period1_turn2': json.dumps(laboratorio_cam_booked_days_period1_turn2),
    'laboratorio_cam_booked_days_period2_turn1': json.dumps(laboratorio_cam_booked_days_period2_turn1),
    'laboratorio_cam_booked_days_period2_turn2': json.dumps(laboratorio_cam_booked_days_period2_turn2),
    
    'laboratorio_ti_1_booked_days_period1_turn1': json.dumps(laboratorio_ti_1_booked_days_period1_turn1),
    'laboratorio_ti_1_booked_days_period1_turn2': json.dumps(laboratorio_ti_1_booked_days_period1_turn2),
    'laboratorio_ti_1_booked_days_period2_turn1': json.dumps(laboratorio_ti_1_booked_days_period2_turn1),
    'laboratorio_ti_1_booked_days_period2_turn2': json.dumps(laboratorio_ti_1_booked_days_period2_turn2),
    
    'laboratorio_ti_2_booked_days_period1_turn1': json.dumps(laboratorio_ti_2_booked_days_period1_turn1),
    'laboratorio_ti_2_booked_days_period1_turn2': json.dumps(laboratorio_ti_2_booked_days_period1_turn2),
    'laboratorio_ti_2_booked_days_period2_turn1': json.dumps(laboratorio_ti_2_booked_days_period2_turn1),
    'laboratorio_ti_2_booked_days_period2_turn2': json.dumps(laboratorio_ti_2_booked_days_period2_turn2),
    
    'laboratorio_ti_3_booked_days_period1_turn1': json.dumps(laboratorio_ti_3_booked_days_period1_turn1),
    'laboratorio_ti_3_booked_days_period1_turn2': json.dumps(laboratorio_ti_3_booked_days_period1_turn2),
    'laboratorio_ti_3_booked_days_period2_turn1': json.dumps(laboratorio_ti_3_booked_days_period2_turn1),
    'laboratorio_ti_3_booked_days_period2_turn2': json.dumps(laboratorio_ti_3_booked_days_period2_turn2),
    
    'laboratorio_ti_4_booked_days_period1_turn1': json.dumps(laboratorio_ti_4_booked_days_period1_turn1),
    'laboratorio_ti_4_booked_days_period1_turn2': json.dumps(laboratorio_ti_4_booked_days_period1_turn2),
    'laboratorio_ti_4_booked_days_period2_turn1': json.dumps(laboratorio_ti_4_booked_days_period2_turn1),
    'laboratorio_ti_4_booked_days_period2_turn2': json.dumps(laboratorio_ti_4_booked_days_period2_turn2),
    
    'laboratorio_Hidraulica_booked_days_period1_turn1': json.dumps(laboratorio_Hidraulica_booked_days_period1_turn1),
    'laboratorio_Hidraulica_booked_days_period1_turn2': json.dumps(laboratorio_Hidraulica_booked_days_period1_turn2),
    'laboratorio_Hidraulica_booked_days_period2_turn1': json.dumps(laboratorio_Hidraulica_booked_days_period2_turn1),
    'laboratorio_Hidraulica_booked_days_period2_turn2': json.dumps(laboratorio_Hidraulica_booked_days_period2_turn2),
    
    'sala_clp_booked_days_period1_turn1': json.dumps(sala_clp_booked_days_period1_turn1),
    'sala_clp_booked_days_period1_turn2': json.dumps(sala_clp_booked_days_period1_turn2),
    'sala_clp_booked_days_period2_turn1': json.dumps(sala_clp_booked_days_period2_turn1),
    'sala_clp_booked_days_period2_turn2': json.dumps(sala_clp_booked_days_period2_turn2),
    
    'laboratorio_Eletroeletronica_booked_days_period1_turn1': json.dumps(laboratorio_Eletroeletronica_booked_days_period1_turn1),
    'laboratorio_Eletroeletronica_booked_days_period1_turn2': json.dumps(laboratorio_Eletroeletronica_booked_days_period1_turn2),
    'laboratorio_Eletroeletronica_booked_days_period2_turn1': json.dumps(laboratorio_Eletroeletronica_booked_days_period2_turn1),
    'laboratorio_Eletroeletronica_booked_days_period2_turn2': json.dumps(laboratorio_Eletroeletronica_booked_days_period2_turn2),
    
    'laboratorio_maquina_comandos_booked_days_period1_turn1': json.dumps(laboratorio_maquina_comandos_booked_days_period1_turn1),
    'laboratorio_maquina_comandos_booked_days_period1_turn2': json.dumps(laboratorio_maquina_comandos_booked_days_period1_turn2),
    'laboratorio_maquina_comandos_booked_days_period2_turn1': json.dumps(laboratorio_maquina_comandos_booked_days_period2_turn1),
    'laboratorio_maquina_comandos_booked_days_period2_turn2': json.dumps(laboratorio_maquina_comandos_booked_days_period2_turn2),
    
    'oficina_eletrica_1_booked_days_period1_turn1': json.dumps(oficina_eletrica_1_booked_days_period1_turn1),
    'oficina_eletrica_1_booked_days_period1_turn2': json.dumps(oficina_eletrica_1_booked_days_period1_turn2),
    'oficina_eletrica_1_booked_days_period2_turn1': json.dumps(oficina_eletrica_1_booked_days_period2_turn1),
    'oficina_eletrica_1_booked_days_period2_turn2': json.dumps(oficina_eletrica_1_booked_days_period2_turn2),
    
    'oficina_eletrica_2_booked_days_period1_turn1': json.dumps(oficina_eletrica_2_booked_days_period1_turn1),
    'oficina_eletrica_2_booked_days_period1_turn2': json.dumps(oficina_eletrica_2_booked_days_period1_turn2),
    'oficina_eletrica_2_booked_days_period2_turn1': json.dumps(oficina_eletrica_2_booked_days_period2_turn1),
    'oficina_eletrica_2_booked_days_period2_turn2': json.dumps(oficina_eletrica_2_booked_days_period2_turn2)
})



from django.shortcuts import render, redirect, get_object_or_404
from .models import Reserva
from .forms import ReservaForm




from django.shortcuts import render

def error_view(request):
    return render(request, 'error.html')  # Renderiza um template de erro

import pandas as pd
from django.http import HttpResponse
from .models import ReservaLog
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
from django.utils.timezone import localtime

from django.db.models import F, Value
from django.db.models.functions import Coalesce

def gerar_excel_view(request):
    # Recuperar os dados de ReservaLog com Coalesce para tratar valores NULL
    logs = ReservaLog.objects.all().select_related(
        'id_reserva', 'id_room', 'id_turno', 'id_periodo', 
        'id_curso', 'id_user'
    ).annotate(
        nome_curso=Coalesce('id_curso__nome_curso', Value('Indefinido'))  # Substituir NULL por "Indefinido"
    ).values(
        'id_log', 'id_reserva_id', 'id_room_id', 'id_turno_id', 'id_periodo_id', 
        'reserved_day', 'id_curso_id', 'id_user_id', 'reserve_time',
        'id_reserva__id_user__nome',  # Nome do usuário
        'id_room__nome',  # Nome da sala
        'id_turno__nome',  # Nome do turno
        'id_periodo__nome',  # Nome do período
        'nome_curso'  # Nome do curso tratado com Coalesce
    )

    # Converter para DataFrame
    df = pd.DataFrame(logs)

    # Substituir valores nulos remanescentes por "Indefinido" no DataFrame
    df.fillna("Indefinido", inplace=True)

    # Remover o fuso horário de reserve_time (se houver)
    if 'reserve_time' in df.columns:
        df['reserve_time'] = df['reserve_time'].apply(lambda x: x.replace(tzinfo=None) if isinstance(x, pd.Timestamp) and x.tzinfo else x)

    # Renomear as colunas para algo mais amigável
    df.columns = [
        'ID Log', 'ID Reserva', 'ID Sala', 'ID Turno', 'ID Período', 
        'Data da Reserva', 'ID Curso', 'ID Usuário', 'Hora da Reserva',
        'Nome do Usuário', 'Nome da Sala', 'Nome do Turno', 'Nome do Período', 'Nome do Curso'
    ]

    # Criar a resposta para download do Excel
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=relatorio_reservas.xlsx'

    # Escrever o DataFrame para o Excel
    with pd.ExcelWriter(response, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Reservas Log')

        # Acessar a planilha criada
        worksheet = writer.sheets['Reservas Log']

        # Adicionar cor no cabeçalho (cor #8B0000)
        header_cells = worksheet[1]  # primeira linha do cabeçalho
        for cell in header_cells:
            cell.fill = PatternFill(start_color="8B0000", end_color="8B0000", fill_type="solid")  # Cor vermelha escura
            cell.font = Font(bold=True, color="FFFFFF")  # Deixar em negrito e texto branco
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Centralizar o texto

        # Ajustar a largura das colunas automaticamente e aumentar um pouco a largura
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter  # Pega o nome da coluna
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 5)  # Ajuste a largura (aumentado um pouco)
            worksheet.column_dimensions[column].width = adjusted_width

        # Adicionar borda em todas as células da tabela
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                             top=Side(style='thin'), bottom=Side(style='thin'))
        
        for row in worksheet.iter_rows():
            for cell in row:
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center", vertical="center")  # Centralizar o texto

        # Garantir que a hora da reserva seja escrita corretamente
        for row in worksheet.iter_rows(min_row=2, min_col=9, max_col=9):  # Coluna da hora da reserva
            for cell in row:
                if isinstance(cell.value, pd.Timestamp):
                    cell.value = cell.value.strftime("%Y-%m-%d %H:%M:%S")  # Formato de data

    return response




# View de Página Protegida (Apenas para usuários autenticados)
def pagina_protegida(request):
    if not usuario_autenticado(request):
        return redirect('login')  # Redireciona para o login se não estiver autenticado
    
    # Caso o usuário esteja autenticado, buscamos as informações dele
    usuario = Usuario.objects.get(id_user=request.session['usuario_id'])
    return render(request, 'pagina_protegida.html', {'usuario': usuario})

# View de Logout
def logout_view(request):
    request.session.flush()  # Remove todas as informações da sessão
    return redirect('login')  # Redireciona para a página de login


## @csrf_exempt
def reset_senha(request):
    return render(request, 'reset_senha.html') # Apenas função para fazer a renderização da página com html

## @csrf_exempt
from django.shortcuts import render

def inicio(request):

    data_atual = date.today()
    
    # Recebe o parâmetro de filtro da sala, se houver
    sala_id = request.GET.get('sala', None)
    
    # Inicia a consulta das reservas com filtro para o dia atual
    reservas = Reserva.objects.filter(reserved_day=data_atual)
    
    # Aplica o filtro de sala, caso esteja presente
    if sala_id:
        reservas = reservas.filter(id_room_id=sala_id)
    
    # Carrega todas as salas para exibição nos botões de filtro
    salas = Sala.objects.all()
    
    nomes_customizados = {
        1: "Auditório",
        2: "Biblioteca",
        3: "OF. Automobilíst.",
        4: "OF. Costura",
        5: "Lab. Metrologia",
        6: "Lab. Automação Residencial",
        7: "Sala de Solda",
        8: "OF. Usinagem",
        9: "Lab. Redes TI",
        10: "Sala C1",
        11: "Sala C2",
        12: "Sala C3",
        13: "Lab. Admin.",
        14: "Sala C5",
        15: "Lab. CAD",
        16: "Lab. CAM",
        17: "Lab. TI 1",
        18: "Lab. TI 2",
        19: "Lab. TI 3",
        20: "Lab. TI 4",
        21: "Lab. Hidráulica",
        22: "Sala CLP",
        23: "Lab. Eletroelet.",
        24: "Lab. Maquinas e Comandos",
        25: "OF. Elétrica 1",
        26: "OF. Elétrica 2",
        
    }
    # Adiciona o nome customizado como atributo extra para cada sala
    for sala in salas:
        sala.nome_customizado = nomes_customizados.get(sala.id_room, sala.nome)  # Usa o nome padrão se não estiver no dicionário

    return render(request, 'index.html', {
        'reservas': reservas,
        'salas': salas,  # As salas agora têm o atributo `nome_customizado`
    })


## @login_required(login_url='login')


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Usuario

import logging
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Usuario, Categoria, Cursos, Sala, Turno, Periodo, Status

import logging
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Usuario, Categoria, Cursos, Sala, Turno, Periodo, Status

# Configuração do logge

import logging
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Usuario, Categoria, Cursos, Sala, Turno, Periodo, Status

# Configuração do logger

@login_required(login_url='login')
def demonstrativo(request):

    # Dados a serem passados para o template
    usuarios = Usuario.objects.all()
    categorias = Categoria.objects.all()
    cursos = Cursos.objects.all()
    salas = Sala.objects.all()
    turnos = Turno.objects.all()
    periodos = Periodo.objects.all()
    statuses = Status.objects.all()

    # Adiciona o caminho da imagem para cada usuário
    for usuario in usuarios:
        usuario.imagem_url = usuario.imagem if usuario.imagem else None

    # Renderiza o template
    return render(request, 'demonstrativo.html', {
        'usuarios': usuarios,
        'categorias': categorias,
        'cursos': cursos,
        'salas': salas,
        'turnos': turnos,
        'periodos': periodos,
        'statuses': statuses,
    })







from django.contrib.auth.decorators import login_required
from .models import Reserva, Sala

@login_required(login_url='login')
def minhas_reservas(request):
    # Pegando o ID do usuário logado
    user_id = request.user.id_user  # ID do usuário logado
    
    # Inicializa a consulta para pegar as reservas do usuário
    reservas = Reserva.objects.filter(id_user_id=user_id)  # Usando id_user_id, que é a chave estrangeira

    # Filtros adicionais
    sala_id = request.GET.get('sala', None)
    data_filtro = request.GET.get('data', None)
    turno_filtro = request.GET.get('turno', None)
    periodo_filtro = request.GET.get('periodo', None)

    # Aplicando filtros de forma condicional
    if sala_id:  # Se a sala for selecionada, filtra por sala
        reservas = reservas.filter(id_room_id=sala_id)

    if data_filtro:  # Se a data for preenchida, filtra por data
        reservas = reservas.filter(reserved_day=data_filtro)

    if turno_filtro:  # Se o turno for preenchido, filtra por turno
        reservas = reservas.filter(id_turno__nome=turno_filtro)

    if periodo_filtro:  # Se o período for preenchido, filtra por período
        reservas = reservas.filter(id_periodo__nome=periodo_filtro)

    # Pegando todas as salas para o filtro de salas
    salas = Sala.objects.all()

    return render(request, 'minhas_reservas.html', {
        'reservas': reservas,
        'salas': salas,
        'data_filtro': data_filtro,
        'turno_filtro': turno_filtro,
        'periodo_filtro': periodo_filtro,
    })



from django.shortcuts import render
from .models import ReservaLog

def relatorio(request):
    # Obtém todos os logs de reserva, ordenados pela data de criação (se necessário)
    logs = ReservaLog.objects.all()

    # Passa os logs para o template
    return render(request, 'relatorio.html', {'logs': logs})

from django.shortcuts import render
from .models import Reserva, Sala
from datetime import date


@csrf_exempt
def reservas(request):
    # Definindo o dia atual como o valor padrão de data
    data_atual = date.today()

    # Pegando os filtros da URL (se houver)
    sala_id = request.GET.get('sala', None)
    data_filtro = request.GET.get('data', data_atual)  # Se não houver data na URL, usa o dia atual
    turno_filtro = request.GET.get('turno', None)
    periodo_filtro = request.GET.get('periodo', None)

    # Inicializa a consulta para pegar todas as reservas
    reservas = Reserva.objects.all()

    # Aplicando os filtros de forma condicional
    if sala_id:  # Se a sala for selecionada, filtra por sala
        reservas = reservas.filter(id_room_id=sala_id)

    if data_filtro:  # Se a data for preenchida, filtra por data
        reservas = reservas.filter(reserved_day=data_filtro)

    if turno_filtro:  # Se o turno for preenchido, filtra por turno
        reservas = reservas.filter(id_turno__nome=turno_filtro)

    if periodo_filtro:  # Se o período for preenchido, filtra por período
        reservas = reservas.filter(id_periodo__nome=periodo_filtro)

    # Pegando todas as salas para o filtro de salas
    reservas_com_status = reservas.select_related('id_status')  # Inclui o status relacionado para otimizar a consulta
    salas = Sala.objects.all()

    return render(request, 'reservas.html', {
        'reservas': reservas_com_status,
        'salas': salas,
        'data_filtro': data_filtro,
        'turno_filtro': turno_filtro,
        'periodo_filtro': periodo_filtro,
    })

from django.http import HttpResponse
import pandas as pd
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from .models import Reserva, Sala, Turno, Periodo, Status
from django.contrib.auth.decorators import login_required
from datetime import date, timedelta

@login_required
def gerar_excel_reservas(request):
    # Preparar os dados-base
    salas = Sala.objects.all()
    turnos = Turno.objects.all()
    periodos = Periodo.objects.all()
    status_list = Status.objects.all()

    # Determinando todas as datas do ano atual
    ano_atual = date.today().year
    data_inicial = date(ano_atual, 1, 1)
    data_final = date(ano_atual, 12, 31)

    # Gerar todas as combinações possíveis
    data = []
    for sala in salas:
        for turno in turnos:
            for periodo in periodos:
                for dia in (data_inicial + timedelta(days=i) for i in range((data_final - data_inicial).days + 1)):
                    reserva_existente = Reserva.objects.filter(
                        id_room=sala,
                        id_turno=turno,
                        id_periodo=periodo,
                        reserved_day=dia
                    ).first()

                    if reserva_existente:
                        status = reserva_existente.id_status.nome
                        reservante = reserva_existente.id_user.nome
                    else:
                        status = "Disponível"
                        reservante = "N/A"

                    data.append({
                        'Sala': sala.nome,
                        'Data': dia,
                        'Turno': turno.nome,
                        'Período': periodo.nome,
                        'Reservante': reservante,
                        'Status': status,
                    })

    # Convertendo para DataFrame
    df = pd.DataFrame(data)

    # Criando a resposta para o Excel
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=reservas_ano_completo.xlsx'

    # Gerando o arquivo Excel
    with pd.ExcelWriter(response, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Reservas')

        # Personalizando a planilha
        worksheet = writer.sheets['Reservas']

        # Estilizar o cabeçalho
        header_cells = worksheet[1]
        for cell in header_cells:
            cell.fill = PatternFill(start_color="8B0000", end_color="8B0000", fill_type="solid")
            cell.font = Font(bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center", vertical="center")

        # Adicionar bordas e centralizar textos
        thin_border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )
        for row in worksheet.iter_rows(min_row=1, max_row=worksheet.max_row, min_col=1, max_col=worksheet.max_column):
            for cell in row:
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center", vertical="center")

        # Ajustar largura das colunas
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter
            for cell in col:
                try:
                    max_length = max(max_length, len(str(cell.value)))
                except Exception:
                    pass
            worksheet.column_dimensions[column].width = max_length + 2

    return response

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .forms import UsuarioEditForm
from .models import Usuario

def editar_usuario(request, id_user):
    usuario = get_object_or_404(Usuario, id_user=id_user)
    
    if request.method == 'POST':
        form = UsuarioEditForm(request.POST, request.FILES, instance=usuario)
        if form.is_valid():
            form.save()
            return redirect('demonstrativo')  # Redireciona para a página de lista de usuários ou outro lugar desejado
    else:
        form = UsuarioEditForm(instance=usuario)

    return render(request, 'editar_usuario.html', {'form': form, 'usuario': usuario})

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .forms import CursoEditForm
from .models import Cursos

def editar_curso(request, id_curso):
    curso = get_object_or_404(Cursos, id_curso=id_curso)
    
    if request.method == 'POST':
        form = CursoEditForm(request.POST, instance=curso)
        if form.is_valid():
            form.save()
            return redirect('demonstrativo')  # Redireciona para a página de lista de cursos ou outro lugar desejado
    else:
        form = CursoEditForm(instance=curso)

    return render(request, 'editar_curso.html', {'form': form, 'curso': curso})

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Cursos

def excluir_curso(request, id_curso):
    curso = get_object_or_404(Cursos, id_curso=id_curso)
    
    if request.method == 'POST':
        curso.delete()
        return redirect('demonstrativo')
    
    return render(request, 'confirmar_exclusao_curso.html', {'curso': curso})



# views.py
from django.shortcuts import render, redirect
from .forms import CursoEditForm

def adicionar_curso(request):
    if request.method == 'POST':
        form = CursoEditForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('demonstrativo')  # Redireciona para a página de lista de cursos
    else:
        form = CursoEditForm()

    return render(request, 'adicionar_curso.html', {'form': form})

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Usuario

def excluir_usuario(request, id_user):
    usuario = get_object_or_404(Usuario, id_user=id_user)
    
    if request.method == 'POST':
        usuario.delete()
        return redirect('demonstrativo')
    
    return render(request, 'confirmar_exclusao_usuario.html', {'usuario': usuario})

def excluir_sala(request, id_room):
    sala = get_object_or_404(Sala, id_room=id_room)
    
    if request.method == 'POST':
        sala.delete()
        return redirect('demonstrativo')  # Redireciona para a página de lista de salas
    
    return render(request, 'confirmar_exclusao_sala.html', {'sala': sala})

# views.py
from django.shortcuts import render, redirect
from .forms import SalaForm

def adicionar_sala(request):
    if request.method == 'POST':
        form = SalaForm(request.POST)
        if form.is_valid():
            form.save()  # Salva os dados no banco
            return redirect('demonstrativo')  # Redireciona para a página de listagem de salas
    else:
        form = SalaForm()

    return render(request, 'adicionar_sala.html', {'form': form})

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .forms import SalaForm
from .models import Sala

def editar_sala(request, id_room):
    sala = get_object_or_404(Sala, id_room=id_room)

    if request.method == 'POST':
        form = SalaForm(request.POST, instance=sala)  # Liga o formulário à instância da sala
        if form.is_valid():
            form.save()  # Salva as alterações no banco de dados
            return redirect('demonstrativo')  # Redireciona para a página de listagem de salas
    else:
        form = SalaForm(instance=sala)  # Preenche o formulário com os dados da sala

    return render(request, 'editar_sala.html', {'form': form, 'sala': sala})

# views.py
from django.shortcuts import render, redirect
from .forms import StatusForm

def adicionar_status(request):
    if request.method == 'POST':
        form = StatusForm(request.POST)
        if form.is_valid():
            form.save()  # Salva os dados no banco
            return redirect('demonstrativo')  # Redireciona para a página de listagem de status
    else:
        form = StatusForm()

    return render(request, 'adicionar_status.html', {'form': form})

# views.py
from django.shortcuts import render, redirect
from .forms import CategoriaForm

def adicionar_categoria(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()  # Salva os dados no banco de dados
            return redirect('demonstrativo')  # Redireciona para a página de listagem de categorias
    else:
        form = CategoriaForm()

    return render(request, 'adicionar_categoria.html', {'form': form})

# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Reserva, Usuario, Cursos, Status

def editar_reserva(request, reserva_id):
    reserva = get_object_or_404(Reserva, id_reserva=reserva_id)  # Obtém a reserva pelo ID ou retorna 404

    # Buscar os nomes dos registros relacionados
    nome_usuario = Usuario.objects.get(id_user=1).nome  # Nome do usuário com ID 1
    nome_curso = Cursos.objects.get(id_curso=1).nome_curso  # Nome do curso com ID 1
    nome_status = Status.objects.get(id_status=1).nome  # Nome do status com ID 1

    if request.method == 'POST':  # Quando o formulário é enviado
        # Atualiza os valores específicos
        reserva.id_user_id = 1
        reserva.id_curso_id = 1
        reserva.id_status_id = 1
        reserva.save()  # Salva as alterações no banco de dados
        return redirect('reservas')  # Redireciona para a listagem de reservas

    return render(request, 'editar_reserva.html', {
        'reserva': reserva,
        'nome_usuario': nome_usuario,
        'nome_curso': nome_curso,
        'nome_status': nome_status,
    })

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from .models import Reserva, Usuario, Cursos, Status

@login_required(login_url='login')
def editar_reserva_usuario(request, reserva_id):
    # Obtém a reserva pelo ID e verifica se pertence ao usuário logado
    reserva = get_object_or_404(Reserva, id_reserva=reserva_id, id_user_id=request.user.id_user)

    # Pega os nomes para exibir no template
    nome_usuario = Usuario.objects.get(id_user=1).nome
    nome_curso = Cursos.objects.get(id_curso=1).nome_curso
    nome_status = Status.objects.get(id_status=1).nome

    if request.method == 'POST':  # Quando o formulário é submetido
        # Atualiza os campos
        reserva.id_user_id = 1
        reserva.id_curso_id = 1
        reserva.id_status_id = 1
        reserva.save()  # Salva as alterações no banco de dados
        return redirect('minhas_reservas')  # Redireciona para a listagem das reservas do usuário

    return render(request, 'editar_reserva_usuario.html', {
        'reserva': reserva,
        'nome_usuario': nome_usuario,
        'nome_curso': nome_curso,
        'nome_status': nome_status,
    })

