import requests
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode

from django.utils.encoding import force_bytes

from django.contrib.auth.models import User
from django.utils.encoding import force_text

# Função para gerar o token de redefinição de senha
def generate_password_reset_token(user):
    # Gerar o token para redefinição de senha
    token = default_token_generator.make_token(user)
    
    # Codificar o ID do usuário de forma segura
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    
    return uid, token

# Função para enviar o e-mail de redefinição de senha via Mailgun
def send_mailgun_reset_email(user_email, reset_link):
    # Configuração da API do Mailgun
    MAILGUN_API_KEY = '689beebf3152e798569719e7e56b5a24-f55d7446-a344212d'
    DOMAIN_NAME = 'sandboxaab1c03a793f41419bbf7991b3b8203f.mailgun.org'
    FROM_EMAIL = 'atlasreservadesala@gmail.com'
    
    # Montar o corpo do e-mail
    subject = 'Password Reset Request'
    body = f'Click here to reset your password: {reset_link}'
    
    # Dados da requisição
    data = {
        'from': FROM_EMAIL,
        'to': user_email,
        'subject': subject,
        'text': body,
    }

    # Enviar o e-mail via API do Mailgun
    response = requests.post(
        f'https://api.mailgun.net/v3/{DOMAIN_NAME}/messages',
        auth=('api', MAILGUN_API_KEY),
        data=data
    )

    if response.status_code == 200:
        return True
    else:
        print(f'Error sending email: {response.text}')
        return False

# Função para processar a solicitação de redefinição de senha
def send_password_reset_email(user_email, request):
    try:
        # Recupera o objeto do usuário a partir do e-mail
        user = User.objects.get(email=user_email)
        
        # Gerar o token e o UID para o link de redefinição de senha
        uid, token = generate_password_reset_token(user)
        
        # Criar o link de redefinição
        reset_link = f"http://127.0.0.1:8000/auth/reset-password/{uid}/{token}/"
        
        # Enviar o e-mail de redefinição de senha
        email_sent = send_mailgun_reset_email(user_email, reset_link)
        
        return email_sent
        
    except User.DoesNotExist:
        return False  # Se o usuário não for encontrado, retorna falso.
