# Importando a biblioteca do Django
from django import forms

class LoginForm(forms.Form):
    email = forms.EmailField(label='Email', max_length=100)
    senha = forms.CharField(label='Senha', widget=forms.PasswordInput)
    # Apenas criando um formulário solicitando email e senha

from django import forms
from .models import Reserva

class ReservaForm(forms.ModelForm):
    class Meta:
        model = Reserva
        fields = ['id_user', 'id_curso', 'id_status']  # Coloque os campos desejados

        # forms.py
from django import forms
from .models import Usuario

class UsuarioEditForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['nome', 'email', 'telefone', 'id_categoria']

    # Se quiser validar campos adicionais ou customizar a lógica de validação, você pode adicionar um método `clean`

    # forms.py
from django import forms
from .models import Cursos

class CursoEditForm(forms.ModelForm):
    class Meta:
        model = Cursos
        fields = ['nome_curso', 'status_curso']

# forms.py
from django import forms
from .models import Sala

class SalaForm(forms.ModelForm):
    class Meta:
        model = Sala
        fields = ['nome']  # Campos que o formulário irá manipular
        labels = {
            'nome': 'Nome da Sala',
        }
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
        }
    
# forms.py
from django import forms
from .models import Status

class StatusForm(forms.ModelForm):
    class Meta:
        model = Status
        fields = ['nome']  # Campos a serem manipulados
        labels = {
            'nome': 'Nome do Status',
        }
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
        }

# forms.py
from django import forms
from .models import Categoria

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nome']  # Campos do formulário
        labels = {
            'nome': 'Nome da Categoria',
        }
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
        }


# AtlaS/forms.py

from django import forms
from django.contrib.auth.forms import PasswordResetForm

class CustomPasswordResetForm(PasswordResetForm):
    email = forms.EmailField(max_length=254, widget=forms.EmailInput(attrs={'class': 'form-control'}))

