from django.contrib.auth.backends import BaseBackend
from .models import Usuario

class EmailBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            # Busca o usuário pelo e-mail (que será usado como 'username')
            usuario = Usuario.objects.get(email=username)
            
            # Aqui, comparamos o campo 'senha' com o password fornecido
            if usuario.senha == password:
                return usuario  # Retorna o usuário se a senha estiver correta
        except Usuario.DoesNotExist:
            return None  # Caso o usuário não exista, retorna None

    def get_user(self, user_id):
        try:
            # Busca o usuário pelo ID (com a primary key)
            return Usuario.objects.get(pk=user_id)
        except Usuario.DoesNotExist:
            return None  # Caso o usuário não exista, retorna None
