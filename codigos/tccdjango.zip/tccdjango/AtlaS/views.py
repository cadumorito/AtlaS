# Importando as biliotecas e informações de outros arquivos
from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as login_django
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import smart_bytes
from django.utils.http import urlsafe_base64_encode
from django.core.mail import send_mail
from django.urls import reverse
from django.shortcuts import render
from django.contrib.auth.models import User
# views.py
from .models import Usuario, Categoria

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render
from .models import Usuario


import os
from PIL import Image
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from AtlaS.models import Usuario  # Certifique-se de usar o modelo correto
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def cadastro(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        email = request.POST['email']
        senha = request.POST['senha']
        telefone = request.POST['telefone']
        imagem = request.FILES.get('imagem')
        id_categoria = request.POST.get('id_categoria')
        
        try:
            categoria = Categoria.objects.get(id_categoria=int(id_categoria))
        except Categoria.DoesNotExist:
            return HttpResponse("Categoria não encontrada.", status=404)
        
        senha_criptografada = make_password(senha)

        usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha_criptografada,  # Apenas hash a senha ao salvar
            telefone=telefone,
            id_categoria=categoria
        )
        usuario.save()
        
        if imagem:
            pasta_fotos = os.path.join('AtlaS', 'static', 'AtlaS', 'images', 'media', 'fotos_de_perfil')
            os.makedirs(pasta_fotos, exist_ok=True)
            
            img = Image.open(imagem)
            img = img.resize((500, 500), Image.LANCZOS)
            
            primeiro_nome = nome.split()[0].capitalize()
            novo_nome = f"{primeiro_nome}{usuario.id_user}.png"
            caminho_completo = os.path.join(pasta_fotos, novo_nome)
            
            img.save(caminho_completo)
            
            usuario.imagem = f'AtlaS/images/media/fotos_de_perfil/{novo_nome}'
            usuario.save()
        
        messages.success(request, 'Usuário cadastrado com sucesso!')
        return redirect('login')
    
    return render(request, 'cadastro.html')

from django.contrib.auth.hashers import check_password
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth import get_backends
from AtlaS.models import Usuario

@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        
        try:
            # Busca o usuário pelo email
            usuario = Usuario.objects.get(email=email)
            
            # Verifica a senha fornecida com a senha criptografada
            if check_password(senha, usuario.senha):
                # Define o backend manualmente no usuário
                backend = get_backends()[0]  # Usa o primeiro backend na lista de backends configurados
                usuario.backend = f"{backend.__module__}.{backend.__class__.__name__}"
                
                # Faz o login do usuário autenticado
                login(request, usuario)
                return redirect('inicio')
            else:
                return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
        
        except Usuario.DoesNotExist:
            return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
    
    return render(request, 'login.html')



# Função para requisitar a troca de senha da conta
def send_password_reset_email(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        # Pede para o email
        try:
            user = User.objects.get(email=email) # Define o user se o email existir
            token = default_token_generator.make_token(user) # Cria um token
            uid = urlsafe_base64_encode(smart_bytes(user.pk)) # Converte para a base64

            reset_link = request.build_absolute_uri(reverse('password_reset_confirm', args=[uid, token])) # Cria o link para resetar a senha

            subject = 'Password Reset Request'
            message = f'Click on the link to reset your password: {reset_link}'
            from_email = 'your_email@example.com'
            recipient_list = [email]
            # Informações que estarão no email
            send_mail(subject, message, from_email, recipient_list)
            # Função de enviar email pegando as informações acima

            # Renderiza com o sucesso
            return render(request, 'reset_senha.html', {'email': email, 'success_message': 'E-mail enviado com sucesso!'})

        except User.DoesNotExist:
            # Erro se algo estiver errado (se o usuário não existir)
            return render(request, 'reset_senha.html', {'error_message': 'Usuário não encontrado com esse email!'})

    else:
        return render(request, 'reset_senha.html') # Renderiza a tela atual


# AtlaS/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.hashers import make_password
from .models import Usuario


# Função personalizada para verificar se o usuário está autenticado
def usuario_autenticado(request):
    return 'usuario_id' in request.session



from .models import Cursos
from datetime import datetime
from django.shortcuts import render, redirect
from django.utils import timezone
import mysql.connector
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
import mysql.connector
from .models import Cursos
import json

import json
import mysql.connector
from django.shortcuts import render
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from .models import Cursos

@login_required(login_url='login')
def formulario(request):
    all_booked_days = []  # Lista para armazenar as datas reservadas com id_status_id = 2
    reserved_days_list = []  # Inicializa a lista para armazenar os dias reservados

    # Verifica se a requisição é do tipo POST
    if request.method == 'POST':
        selected_dates = request.POST.get('selectedDates', '')  # Obtém as datas selecionadas do formulário
        reserved_days_list = selected_dates.split(',') if selected_dates else []  # Divide as datas selecionadas
        
        if not reserved_days_list:  # Caso não haja datas selecionadas
            print("Nenhuma data reservada selecionada.")
            return render(request, 'formulario.html', {
                'cursos': Cursos.objects.filter(status_curso=True),  # Envia os cursos ativos para o template
                'alert_message': 'Por favor, selecione pelo menos um dia para reserva.',
                'reserved_days_list': json.dumps([]),  # Passa uma lista vazia para o JavaScript
                'all_booked_days': json.dumps([]),  # Passa uma lista vazia de datas reservadas
            })
        print(reserved_days_list)
        
        # Obter o nome da sala e mapear para o ID correspondente
        course_name = request.POST.get('course-name')
        room_mapping = {
            "Auditório": 1,
            "Biblioteca": 2,
            "Oficina de Automobilística": 3,
            "Oficina de Costura": 4,
            "Laboratório de Metrologia": 5,
            "Laboratório de Automoção Residencial": 6,
            "Sala de Solda": 7,
            "Oficina de Usinagem": 8,
            "Laboratório de Redes - TI": 9,
            "Sala C1": 10,
            "Sala C2": 11,
            "Sala C3": 12,
            "Laboratório de Administração": 13,
            "Sala C5": 14,
            "Laboratório CAD": 15,
            "Laboratório CAM": 16,
            "Laboratório TI 1": 17,
            "Laboratório TI 2": 18,
            "Laboratório TI 3": 19,
            "Laboratório TI 4": 20,
            "Laboratório de Hidráulica": 21,
            "Sala CLP": 22,
            "Laboratório de Eletroeletrônica": 23,
            "Laboratório de Máquina e Comandos": 24,
            "Oficina Elétrica 1": 25,
            "Oficina Elétrica 2": 26,
        }
        room_python = room_mapping.get(course_name, None)

        # Definir turno e período
        turno_python = 1 if request.POST.get('turn') == 'antes' else 2
        periodo_python = 1 if request.POST.get('period') == 'antes' else 2
        
        # Dados do usuário e horário atual
        newuser_python = request.user.id_user
        current_python_datetime = timezone.now()

        # Conexão com o banco de dados
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="devmysql",
            database="AtlaS"
        )
        cursor = db.cursor()

        # Consulta para pegar as datas reservadas
        cursor.execute("""
            SELECT reserved_day 
            FROM reservas 
            WHERE id_status_id = 2
        """)
        all_booked_days = cursor.fetchall()  # Pega todas as datas com status 2 (reservadas)
        all_booked_days = [str(day[0]) for day in all_booked_days]  # Converte para uma lista de strings de datas

        # Atualiza os dias reservados no banco de dados
        if reserved_days_list:
            placeholders = ', '.join(['%s'] * len(reserved_days_list))
            update_query = f"""
                UPDATE reservas
                SET
                    id_room_id = %s,
                    id_turno_id = %s,
                    id_periodo_id = %s,
                    id_user_id = %s,
                    reserve_time = %s,
                    id_status_id = 2
                WHERE
                    id_room_id = %s AND
                    id_turno_id = %s AND
                    id_periodo_id = %s AND
                    id_status_id = 1 AND
                    reserved_day IN ({placeholders})
            """
            
            # Parâmetros para a consulta de atualização
            params = (
                room_python, turno_python, periodo_python,
                newuser_python, current_python_datetime,
                room_python, turno_python, periodo_python,
            ) + tuple(reserved_days_list)

            try:
                cursor.execute(update_query, params)
                db.commit()
                print(f"{cursor.rowcount} registro(s) atualizado(s) com sucesso.")
            except mysql.connector.Error as e:
                print(f"Erro ao atualizar a tabela: {e}")
                print("Consulta que causou o erro:", cursor.statement)
            finally:
                cursor.close()
                db.close()

    # Renderiza o formulário se não for um POST ou após o POST
    cursos = Cursos.objects.filter(status_curso=True)  # Filtra apenas os cursos com status ativo
    return render(request, 'formulario.html', {
        'cursos': cursos,
        'alert_message': '',  # Se não houver mensagem de alerta
        'reserved_days_list': json.dumps(reserved_days_list),  # Passa a lista de dias reservados para o JavaScript
        'all_booked_days': json.dumps(all_booked_days)  # Passa as datas já reservadas para o JavaScript
    })







from django.shortcuts import render

def error_view(request):
    return render(request, 'error.html')  # Renderiza um template de erro



# View de Página Protegida (Apenas para usuários autenticados)
def pagina_protegida(request):
    if not usuario_autenticado(request):
        return redirect('login')  # Redireciona para o login se não estiver autenticado
    
    # Caso o usuário esteja autenticado, buscamos as informações dele
    usuario = Usuario.objects.get(id_user=request.session['usuario_id'])
    return render(request, 'pagina_protegida.html', {'usuario': usuario})

# View de Logout
def logout_view(request):
    request.session.flush()  # Remove todas as informações da sessão
    return redirect('login')  # Redireciona para a página de login


## @csrf_exempt
def reset_senha(request):
    return render(request, 'reset_senha.html') # Apenas função para fazer a renderização da página com html

## @csrf_exempt
from django.shortcuts import render

def inicio(request):
    data_atual = date.today()
    
    # Recebe o parâmetro de filtro da sala, se houver
    sala_id = request.GET.get('sala', None)
    
    # Inicia a consulta das reservas com filtro para o dia atual
    reservas = Reserva.objects.filter(reserved_day=data_atual)
    
    # Aplica o filtro de sala, caso esteja presente
    if sala_id:
        reservas = reservas.filter(id_room_id=sala_id)
    
    # Carrega todas as salas para exibição nos botões de filtro
    salas = Sala.objects.all()
    
    return render(request, 'index.html', {
        'reservas': reservas,
        'salas': salas,
    })


## @login_required(login_url='login')


from django.shortcuts import render
from .models import Usuario 

# Função da tela demonstrativo
def demonstrativo(request):
    usuarios = Usuario.objects.all() # Define usuarios como todos os objetos do model Usuario

    # Adiciona o caminho da imagem para cada usuário
    for usuario in usuarios: # Para cada usuario em usuarios
        if usuario.imagem: # Se o usuário tiver imagem
            usuario.imagem_url = usuario.imagem  # Pega o caminho da imagem armazenado no banco de dados
        else:
            usuario.imagem_url = None # Caso não possuir, não terá a definição do caminho como variável

    return render(request, 'demonstrativo.html', {'usuarios': usuarios}) # Renderiza a tela atual puxando o html e  os usuários

from django.contrib.auth.decorators import login_required
from .models import Reserva, Sala

@login_required(login_url='login')
def minhas_reservas(request):
    # Pegando o ID do usuário logado
    user_id = request.user.id_user  # ID do usuário logado
    
    # Inicializa a consulta para pegar as reservas do usuário
    reservas = Reserva.objects.filter(id_user_id=user_id)  # Usando id_user_id, que é a chave estrangeira

    # Filtros adicionais
    sala_id = request.GET.get('sala', None)
    data_filtro = request.GET.get('data', None)
    turno_filtro = request.GET.get('turno', None)
    periodo_filtro = request.GET.get('periodo', None)

    # Aplicando filtros de forma condicional
    if sala_id:  # Se a sala for selecionada, filtra por sala
        reservas = reservas.filter(id_room_id=sala_id)

    if data_filtro:  # Se a data for preenchida, filtra por data
        reservas = reservas.filter(reserved_day=data_filtro)

    if turno_filtro:  # Se o turno for preenchido, filtra por turno
        reservas = reservas.filter(id_turno__nome=turno_filtro)

    if periodo_filtro:  # Se o período for preenchido, filtra por período
        reservas = reservas.filter(id_periodo__nome=periodo_filtro)

    # Pegando todas as salas para o filtro de salas
    salas = Sala.objects.all()

    return render(request, 'minhas_reservas.html', {
        'reservas': reservas,
        'salas': salas,
        'data_filtro': data_filtro,
        'turno_filtro': turno_filtro,
        'periodo_filtro': periodo_filtro,
    })





## @login_required(login_url='login')
@csrf_exempt
def relatorio(request):
    return render(request, 'relatorio.html') # Apenas função para fazer a renderização da página com html

from django.shortcuts import render
from .models import Reserva, Sala
from datetime import date

@login_required(login_url='login')
@csrf_exempt
def reservas(request):
    # Definindo o dia atual como o valor padrão de data
    data_atual = date.today()

    # Pegando os filtros da URL (se houver)
    sala_id = request.GET.get('sala', None)
    data_filtro = request.GET.get('data', data_atual)  # Se não houver data na URL, usa o dia atual
    turno_filtro = request.GET.get('turno', None)
    periodo_filtro = request.GET.get('periodo', None)

    # Inicializa a consulta para pegar todas as reservas
    reservas = Reserva.objects.all()

    # Aplicando os filtros de forma condicional
    if sala_id:  # Se a sala for selecionada, filtra por sala
        reservas = reservas.filter(id_room_id=sala_id)

    if data_filtro:  # Se a data for preenchida, filtra por data
        reservas = reservas.filter(reserved_day=data_filtro)

    if turno_filtro:  # Se o turno for preenchido, filtra por turno
        reservas = reservas.filter(id_turno__nome=turno_filtro)

    if periodo_filtro:  # Se o período for preenchido, filtra por período
        reservas = reservas.filter(id_periodo__nome=periodo_filtro)

    # Pegando todas as salas para o filtro de salas
    reservas_com_status = reservas.select_related('id_status')  # Inclui o status relacionado para otimizar a consulta
    salas = Sala.objects.all()

    return render(request, 'reservas.html', {
        'reservas': reservas_com_status,
        'salas': salas,
        'data_filtro': data_filtro,
        'turno_filtro': turno_filtro,
        'periodo_filtro': periodo_filtro,
    })