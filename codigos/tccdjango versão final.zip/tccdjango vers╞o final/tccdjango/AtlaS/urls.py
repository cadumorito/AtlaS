# Importando bibliotecas e informações de outros arquivos, como o views

from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from . import views

# Definindo algumas urls da nossa aplicação
# Urls com as funções de renderização do view.py
urlpatterns = [
    path('editar_usuario/<int:id_user>/', views.editar_usuario, name='editar_usuario'),
    path('excluir_usuario/<int:id_user>/', views.excluir_usuario, name='excluir_usuario'),

    path('adicionar_categoria/', views.adicionar_categoria, name='adicionar_categoria'),

    path('editar_reserva/<int:reserva_id>/', views.editar_reserva, name='editar_reserva'),

    path('editar_reserva_usuario/<int:reserva_id>/', views.editar_reserva_usuario, name='editar_reserva_usuario'),

    path('adicionar_status/', views.adicionar_status, name='adicionar_status'),

    path('excluir_sala/<int:id_room>/', views.excluir_sala, name='excluir_sala'),
    path('adicionar_sala/', views.adicionar_sala, name='adicionar_sala'),
    path('editar_sala/<int:id_room>/', views.editar_sala, name='editar_sala'),

    path('editar_curso/<int:id_curso>/', views.editar_curso, name='editar_curso'),
    path('adicionar_curso/', views.adicionar_curso, name='adicionar_curso'),
    path('excluir_curso/<int:id_curso>/', views.excluir_curso, name='excluir_curso'),

    path('', views.inicio, name='inicio'),
    path('demonstrativo/', views.demonstrativo, name='demonstrativo'),
    path('reservas', views.reservas, name='reservas'),
    path('reservas/formulario/', views.formulario, name='formulario'),
    path('minhas_reservas/', views.minhas_reservas, name='minhas_reservas'),
    path('relatorio/', views.relatorio, name='relatorio'),
    path('recuperar_senha/', views.reset_senha, name='reset_senha'),
    path('cadastro/', views.cadastro, name='cadastro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('error/', views.error_view, name='error_page'),
    path('protegida/', views.pagina_protegida, name='pagina_protegida'),
    # URL para enviar e-mail de recuperação de senha
    path('forgot_password/', views.send_password_reset_email, name='forgot_password'),
    path('gerar_excel/', views.gerar_excel_view, name='gerar_excel'),
    path('reservas/excel/', views.gerar_excel_reservas, name='gerar_excel_reservas'),
    # URL para redefinição de senha
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset/', views.send_password_reset_email, name='password_reset'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)