import mysql.connector
from datetime import datetime

# Conexão com o banco de dados
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="devmysql",
    database="AtlaS"
)

# Criar um cursor para executar comandos SQL
cursor = db.cursor()

# Variáveis que você deseja usar na atualização
room_python = 1  # Exemplo de valor
turno_python = 2  # Exemplo de valor
periodo_python = 2  # Exemplo de valor
reserved_python = "2024-11-27"  # Exemplo de valor
newuser_python = 2  # Exemplo de valor
current_python = "10:00:00"  # Exemplo de valor de horário

# Converter a string de hora para um objeto datetime com a data atual
data_atual = datetime.now().date()
current_python_datetime = datetime.combine(data_atual, datetime.strptime(current_python, "%H:%M:%S").time())

# Comando UPDATE
update_query = """
UPDATE reservas
SET
    id_room_id = %s,
    id_turno_id = %s,
    id_periodo_id = %s,
    reserved_day = %s,
    id_user_id = %s,
    reserve_time = %s,
    id_status_id = 2
WHERE
    id_room_id = %s AND
    id_turno_id = %s AND
    id_periodo_id = %s AND
    id_status_id = 1 AND
    reserved_day = %s
"""

# Parâmetros a serem usados no comando UPDATE
params = (
    room_python, turno_python, periodo_python, reserved_python,
    newuser_python, current_python_datetime, room_python, turno_python,
    periodo_python, reserved_python
)

try:
    # Executar a consulta de atualização
    cursor.execute(update_query, params)
    
    # Salvar as mudanças no banco de dados
    db.commit()
    
    # Exibir o número de registros atualizados
    print(f"{cursor.rowcount} registro(s) atualizado(s) com sucesso.")
    
except mysql.connector.Error as e:
    # Exibir mensagem de erro caso ocorra
    print(f"Erro ao atualizar a tabela: {e}")
    
finally:
    # Fechar o cursor e a conexão
    cursor.close()
    db.close()
