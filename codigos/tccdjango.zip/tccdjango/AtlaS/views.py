# Importando as biliotecas e informações de outros arquivos
from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as login_django
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import smart_bytes
from django.utils.http import urlsafe_base64_encode
from django.core.mail import send_mail
from django.urls import reverse
from django.shortcuts import render
from django.contrib.auth.models import User
# views.py
from .models import Usuario, Categoria

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt

from django.shortcuts import render
from .models import Usuario


import os
from PIL import Image
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Usuario, Categoria
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from AtlaS.models import Usuario  # Certifique-se de usar o modelo correto
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def cadastro(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        email = request.POST['email']
        senha = request.POST['senha']
        telefone = request.POST['telefone']
        imagem = request.FILES.get('imagem')
        id_categoria = request.POST.get('id_categoria')
        
        try:
            categoria = Categoria.objects.get(id_categoria=int(id_categoria))
        except Categoria.DoesNotExist:
            return HttpResponse("Categoria não encontrada.", status=404)
        
        senha_criptografada = make_password(senha)

        usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha_criptografada,  # Apenas hash a senha ao salvar
            telefone=telefone,
            id_categoria=categoria
        )
        usuario.save()
        
        if imagem:
            pasta_fotos = os.path.join('AtlaS', 'static', 'AtlaS', 'images', 'media', 'fotos_de_perfil')
            os.makedirs(pasta_fotos, exist_ok=True)
            
            img = Image.open(imagem)
            img = img.resize((500, 500), Image.LANCZOS)
            
            primeiro_nome = nome.split()[0].capitalize()
            novo_nome = f"{primeiro_nome}{usuario.id_user}.png"
            caminho_completo = os.path.join(pasta_fotos, novo_nome)
            
            img.save(caminho_completo)
            
            usuario.imagem = f'AtlaS/images/media/fotos_de_perfil/{novo_nome}'
            usuario.save()
        
        messages.success(request, 'Usuário cadastrado com sucesso!')
        return redirect('login')
    
    return render(request, 'cadastro.html')

from django.contrib.auth.hashers import check_password
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth import get_backends
from AtlaS.models import Usuario

@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        
        try:
            # Busca o usuário pelo email
            usuario = Usuario.objects.get(email=email)
            
            # Verifica a senha fornecida com a senha criptografada
            if check_password(senha, usuario.senha):
                # Define o backend manualmente no usuário
                backend = get_backends()[0]  # Usa o primeiro backend na lista de backends configurados
                usuario.backend = f"{backend.__module__}.{backend.__class__.__name__}"
                
                # Faz o login do usuário autenticado
                login(request, usuario)
                return redirect('inicio')
            else:
                return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
        
        except Usuario.DoesNotExist:
            return render(request, 'login.html', {'error_message': 'Email ou senha incorretos'})
    
    return render(request, 'login.html')



# Função para requisitar a troca de senha da conta
def send_password_reset_email(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        # Pede para o email
        try:
            user = User.objects.get(email=email) # Define o user se o email existir
            token = default_token_generator.make_token(user) # Cria um token
            uid = urlsafe_base64_encode(smart_bytes(user.pk)) # Converte para a base64

            reset_link = request.build_absolute_uri(reverse('password_reset_confirm', args=[uid, token])) # Cria o link para resetar a senha

            subject = 'Password Reset Request'
            message = f'Click on the link to reset your password: {reset_link}'
            from_email = 'your_email@example.com'
            recipient_list = [email]
            # Informações que estarão no email
            send_mail(subject, message, from_email, recipient_list)
            # Função de enviar email pegando as informações acima

            # Renderiza com o sucesso
            return render(request, 'reset_senha.html', {'email': email, 'success_message': 'E-mail enviado com sucesso!'})

        except User.DoesNotExist:
            # Erro se algo estiver errado (se o usuário não existir)
            return render(request, 'reset_senha.html', {'error_message': 'Usuário não encontrado com esse email!'})

    else:
        return render(request, 'reset_senha.html') # Renderiza a tela atual


# AtlaS/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.hashers import make_password
from .models import Usuario


# Função personalizada para verificar se o usuário está autenticado
def usuario_autenticado(request):
    return 'usuario_id' in request.session



from .models import Cursos
from datetime import datetime
from django.shortcuts import render, redirect
from django.utils import timezone
import mysql.connector
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required

@login_required(login_url='login')
@csrf_exempt  # Garantia de "segurança" para o formulário
def formulario(request):
    if request.method == 'POST':
        # Obter as datas selecionadas como uma lista
        selected_dates = request.POST.get('selectedDates', '')  # Obtém como string
        print(f"Datas selecionadas: {selected_dates}")  # Para debug

        # Se a string estiver vazia, exibir um alerta e permanecer na página
        if not selected_dates:
            print("Nenhuma data reservada selecionada.")
            # Você pode usar um script para mostrar um alerta na página
            # Continuar o formulário, basta fechar o alert

        
        reserved_days_list = selected_dates.split(',')  # Transforma a string em uma lista de dias
        print(f"Lista de dias reservados: {reserved_days_list}")  # Para debug
        
        # Conexão com o banco de dados
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="devmysql",
            database="AtlaS"
        )

        # Criar um cursor para executar comandos SQL
        cursor = db.cursor()
        
    if request.method == 'POST':
        # Obter o nome da sala do campo de entrada
        course_name = request.POST.get('course-name')

        # Definir room_python com base no nome da sala
        if course_name == "Auditório":
            room_python = 1
        elif course_name == "Biblioteca":
            room_python = 2
        elif course_name == "Oficina de Automobilística":
            room_python = 3
        elif course_name == "Oficina de Costura":
            room_python = 4
        elif course_name == "Laboratório de Metrologia":
            room_python = 5
        elif course_name == "Laboratório de Automoção Residencial":
            room_python = 6
        elif course_name == "Sala de Solda":
            room_python = 7
        elif course_name == "Oficina de Usinagem":
            room_python = 8
        elif course_name == "Laboratório de Redes - TI":
            room_python = 9
        elif course_name == "Sala C1":
            room_python = 10
        elif course_name == "Sala C2":
            room_python = 11
        elif course_name == "Sala C3":
            room_python = 12
        elif course_name == "Laboratório de Administração":
            room_python = 13
        elif course_name == "Sala C5":
            room_python = 14
        elif course_name == "Laboratório CAD":
            room_python = 15
        elif course_name == "Laboratório CAM":
            room_python = 16
        elif course_name == "Laboratório TI 1":
            room_python = 17
        elif course_name == "Laboratório TI 2":
            room_python = 18
        elif course_name == "Laboratório TI 3":
            room_python = 19
        elif course_name == "Laboratório TI 4":
            room_python = 20
        elif course_name == "Laboratório de Hidráulica":
            room_python = 21
        elif course_name == "Sala CLP":
            room_python = 22
        elif course_name == "Laboratório de Eletroeletrônica":
            room_python = 23
        elif course_name == "Laboratório de Máquina e Comandos":
            room_python = 24
        elif course_name == "Oficina Elétrica 1":
            room_python = 25
        elif course_name == "Oficina Elétrica 2":
            room_python = 26

        else:
            room_python = None  # ou um valor padrão, se necessário

        turno_python = 1 if request.POST.get('turn') == 'antes' else 2  # De acordo com o input radio selecionado
        periodo_python = 1 if request.POST.get('period') == 'antes' else 2  # De acordo com o input radio selecionado
        
        newuser_python = request.user.id_user  # Pegar o ID do usuário logado
        current_python_datetime = timezone.now()  # Pegar a hora atual do submit

        # Montar a consulta SQL
        if reserved_days_list:
            # Usar placeholders para os dias reservados
            placeholders = ', '.join(['%s'] * len(reserved_days_list))  # Cria um placeholder para cada data
            update_query = f"""
                UPDATE reservas
                SET
                    id_room_id = %s,
                    id_turno_id = %s,
                    id_periodo_id = %s,
                    id_user_id = %s,
                    reserve_time = %s,
                    id_status_id = 2
                WHERE
                    id_room_id = %s AND
                    id_turno_id = %s AND
                    id_periodo_id = %s AND
                    id_status_id = 1 AND
                    reserved_day IN ({placeholders})
            """
        
            # Parâmetros a serem usados no comando UPDATE
            params = (
                room_python, turno_python, periodo_python, 
                newuser_python, current_python_datetime, 
                room_python, turno_python, periodo_python,
            ) + tuple(reserved_days_list)  # Adiciona as datas selecionadas como parâmetros

            # Para depuração, exibir a consulta e os parâmetros
            print("Consulta SQL:", update_query)
            print("Parâmetros:", params)

            try:
                # Executar a consulta de atualização
                cursor.execute(update_query, params)
                
                # Salvar as mudanças no banco de dados
                db.commit()
                
                # Exibir o número de registros atualizados
                print(f"{cursor.rowcount} registro(s) atualizado(s) com sucesso.")
                
            except mysql.connector.Error as e:
                # Exibir mensagem de erro caso ocorra
                print(f"Erro ao atualizar a tabela: {e}")
                print("Consulta que causou o erro:", cursor.statement)
                
            finally:
                # Fechar o cursor e a conexão
                cursor.close()
                db.close()

    # Renderiza o formulário se não for um POST
    cursos = Cursos.objects.filter(status_curso=True)  # Filtra apenas os cursos com status ativo
    return render(request, 'formulario.html', {'cursos': cursos, 'alert_message': ''})



from django.shortcuts import render

def error_view(request):
    return render(request, 'error.html')  # Renderiza um template de erro



# View de Página Protegida (Apenas para usuários autenticados)
def pagina_protegida(request):
    if not usuario_autenticado(request):
        return redirect('login')  # Redireciona para o login se não estiver autenticado
    
    # Caso o usuário esteja autenticado, buscamos as informações dele
    usuario = Usuario.objects.get(id_user=request.session['usuario_id'])
    return render(request, 'pagina_protegida.html', {'usuario': usuario})

# View de Logout
def logout_view(request):
    request.session.flush()  # Remove todas as informações da sessão
    return redirect('login')  # Redireciona para a página de login


## @csrf_exempt
def reset_senha(request):
    return render(request, 'reset_senha.html') # Apenas função para fazer a renderização da página com html

## @csrf_exempt
from django.shortcuts import render

def inicio(request):
    print("Usuário autenticado: ", request.user.is_authenticated)
    print("Usuário: ", request.user)
    return render(request, 'index.html', {'request': request})


## @login_required(login_url='login')


from django.shortcuts import render
from .models import Usuario 

# Função da tela demonstrativo
def demonstrativo(request):
    usuarios = Usuario.objects.all() # Define usuarios como todos os objetos do model Usuario

    # Adiciona o caminho da imagem para cada usuário
    for usuario in usuarios: # Para cada usuario em usuarios
        if usuario.imagem: # Se o usuário tiver imagem
            usuario.imagem_url = usuario.imagem  # Pega o caminho da imagem armazenado no banco de dados
        else:
            usuario.imagem_url = None # Caso não possuir, não terá a definição do caminho como variável

    return render(request, 'demonstrativo.html', {'usuarios': usuarios}) # Renderiza a tela atual puxando o html e  os usuários

## @login_required(login_url='login')
@csrf_exempt
def minhas_reservas(request):
    return render(request, 'minhas_reservas.html') # Apenas função para fazer a renderização da página com html

## @login_required(login_url='login')
@csrf_exempt
def relatorio(request):
    return render(request, 'relatorio.html') # Apenas função para fazer a renderização da página com html

## @login_required(login_url='login')
@csrf_exempt
def reservas(request):
    return render(request, 'reservas.html') # Apenas função para fazer a renderização da página com html


