document.addEventListener('DOMContentLoaded', () => {
    const periodRadios = document.querySelectorAll('input[name="period"]');
    const turnRadios = document.querySelectorAll('input[name="turn"]');

    console.log('Manhã antes: ' + bookedDaysPeriod1Turn1);
    console.log('Manhã após: ' + bookedDaysPeriod1Turn2);
    console.log('Tarde antes: ' + bookedDaysPeriod2Turn1);
    console.log('Tarde após: ' + bookedDaysPeriod2Turn2);
    console.log('Auditório: ' + auditorioBookedDaysPeriod1Turn1);
    console.log('Biblioteca: ' + bibliotecaBookedDaysPeriod1Turn1);
    console.log('Automobilística: ' + oficinaAutomobilisticaBookedDaysPeriod1Turn1);
    console.log(oficinaCosturaBookedDaysPeriod2Turn1);
    console.log(laboratorioMetrologiaBookedDaysPeriod1Turn1);
    console.log(laboratorioAutomacaoResidencialBookedDaysPeriod1Turn1);
    console.log(salaSoldaBookedDaysPeriod1Turn1);
    console.log(oficinaUsinagemBookedDaysPeriod1Turn1);
    console.log(laboratorioRedesTIBookedDaysPeriod1Turn1);
    console.log(salaC1BookedDaysPeriod1Turn1);
    console.log(salaC2BookedDaysPeriod1Turn1);
    console.log(salaC3BookedDaysPeriod1Turn1);
    console.log(salaC5BookedDaysPeriod1Turn1);
    console.log(laboratorioCAMBookedDaysPeriod1Turn1);
    console.log(laboratorioCADBookedDaysPeriod1Turn1);
    console.log(laboratorioTI1BookedDaysPeriod1Turn1);
    console.log(laboratorioTI2BookedDaysPeriod1Turn1);
    console.log(laboratorioTI3BookedDaysPeriod1Turn1);
    console.log(laboratorioTI4BookedDaysPeriod1Turn1);
    console.log(laboratorioHidraulicaBookedDaysPeriod1Turn1);
    console.log(salaCLPBookedDaysPeriod1Turn1);
    console.log(laboratorioEletroeletronicaBookedDaysPeriod1Turn1);
    console.log(laboratorioMaquinaComandosBookedDaysPeriod1Turn1);
    console.log(oficinaEletrica1BookedDaysPeriod1Turn1);
    console.log(oficinaEletrica2BookedDaysPeriod1Turn1);

    // Mapeamento das salas com os dados de reservas por turno
    const salaMapping = {
        'Auditório': {
            manhaAntes: auditorioBookedDaysPeriod1Turn1,
            manhaApos: auditorioBookedDaysPeriod1Turn2,
            tardeAntes: auditorioBookedDaysPeriod2Turn1,
            tardeApos: auditorioBookedDaysPeriod2Turn2,
        },
        'Biblioteca': {
            manhaAntes: bibliotecaBookedDaysPeriod1Turn1,
            manhaApos: bibliotecaBookedDaysPeriod1Turn2,
            tardeAntes: bibliotecaBookedDaysPeriod2Turn1,
            tardeApos: bibliotecaBookedDaysPeriod2Turn2,
        },
        'Oficina de Automobilística': {
            manhaAntes: oficinaAutomobilisticaBookedDaysPeriod1Turn1,
            manhaApos: oficinaAutomobilisticaBookedDaysPeriod1Turn2,
            tardeAntes: oficinaAutomobilisticaBookedDaysPeriod2Turn1,
            tardeApos: oficinaAutomobilisticaBookedDaysPeriod2Turn2,
        },
        'Oficina de Costura': {
            manhaAntes: oficinaCosturaBookedDaysPeriod1Turn1,
            manhaApos: oficinaCosturaBookedDaysPeriod1Turn2,
            tardeAntes: oficinaCosturaBookedDaysPeriod2Turn1,
            tardeApos: oficinaCosturaBookedDaysPeriod2Turn2,
        },
        'Laboratório de Metrologia': {
            manhaAntes: laboratorioMetrologiaBookedDaysPeriod1Turn1,
            manhaApos: laboratorioMetrologiaBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioMetrologiaBookedDaysPeriod2Turn1,
            tardeApos: laboratorioMetrologiaBookedDaysPeriod2Turn2,
        },
        'Laboratório de Automação Residencial': {
            manhaAntes: laboratorioAutomacaoResidencialBookedDaysPeriod1Turn1,
            manhaApos: laboratorioAutomacaoResidencialBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioAutomacaoResidencialBookedDaysPeriod2Turn1,
            tardeApos: laboratorioAutomacaoResidencialBookedDaysPeriod2Turn2,
        },
        'Sala de Solda': {
            manhaAntes: salaSoldaBookedDaysPeriod1Turn1,
            manhaApos: salaSoldaBookedDaysPeriod1Turn2,
            tardeAntes: salaSoldaBookedDaysPeriod2Turn1,
            tardeApos: salaSoldaBookedDaysPeriod2Turn2,
        },
        'Oficina de Usinagem': {
            manhaAntes: oficinaUsinagemBookedDaysPeriod1Turn1,
            manhaApos: oficinaUsinagemBookedDaysPeriod1Turn2,
            tardeAntes: oficinaUsinagemBookedDaysPeriod2Turn1,
            tardeApos: oficinaUsinagemBookedDaysPeriod2Turn2,
        },
        'Laboratório de Redes - TI': {
            manhaAntes: laboratorioRedesTIBookedDaysPeriod1Turn1,
            manhaApos: laboratorioRedesTIBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioRedesTIBookedDaysPeriod2Turn1,
            tardeApos: laboratorioRedesTIBookedDaysPeriod2Turn2,
        },
        'Sala C1': {
            manhaAntes: salaC1BookedDaysPeriod1Turn1,
            manhaApos: salaC1BookedDaysPeriod1Turn2,
            tardeAntes: salaC1BookedDaysPeriod2Turn1,
            tardeApos: salaC1BookedDaysPeriod2Turn2,
        },
        'Sala C2': {
            manhaAntes: salaC2BookedDaysPeriod1Turn1,
            manhaApos: salaC2BookedDaysPeriod1Turn2,
            tardeAntes: salaC2BookedDaysPeriod2Turn1,
            tardeApos: salaC2BookedDaysPeriod2Turn2,
        },
        'Sala C3': {
            manhaAntes: salaC3BookedDaysPeriod1Turn1,
            manhaApos: salaC3BookedDaysPeriod1Turn2,
            tardeAntes: salaC3BookedDaysPeriod2Turn1,
            tardeApos: salaC3BookedDaysPeriod2Turn2,
        },
        'Laboratório de Administração': {
            manhaAntes: laboratorioAdministracaoBookedDaysPeriod1Turn1,
            manhaApos: laboratorioAdministracaoBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioAdministracaoBookedDaysPeriod2Turn1,
            tardeApos: laboratorioAdministracaoBookedDaysPeriod2Turn2,
        },
        'Laboratório CAD': {
            manhaAntes: laboratorioCADBookedDaysPeriod1Turn1,
            manhaApos: laboratorioCADBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioCADBookedDaysPeriod2Turn1,
            tardeApos: laboratorioCADBookedDaysPeriod2Turn2,
        },
        'Laboratório CAM': {
            manhaAntes: laboratorioCAMBookedDaysPeriod1Turn1,
            manhaApos: laboratorioCAMBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioCAMBookedDaysPeriod2Turn1,
            tardeApos: laboratorioCAMBookedDaysPeriod2Turn2,
        },
        'Laboratório TI 1': {
            manhaAntes: laboratorioTI1BookedDaysPeriod1Turn1,
            manhaApos: laboratorioTI1BookedDaysPeriod1Turn2,
            tardeAntes: laboratorioTI1BookedDaysPeriod2Turn1,
            tardeApos: laboratorioTI1BookedDaysPeriod2Turn2,
        },
        'Laboratório TI 2': {
            manhaAntes: laboratorioTI2BookedDaysPeriod1Turn1,
            manhaApos: laboratorioTI2BookedDaysPeriod1Turn2,
            tardeAntes: laboratorioTI2BookedDaysPeriod2Turn1,
            tardeApos: laboratorioTI2BookedDaysPeriod2Turn2,
        },
        'Laboratório TI 3': {
            manhaAntes: laboratorioTI3BookedDaysPeriod1Turn1,
            manhaApos: laboratorioTI3BookedDaysPeriod1Turn2,
            tardeAntes: laboratorioTI3BookedDaysPeriod2Turn1,
            tardeApos: laboratorioTI3BookedDaysPeriod2Turn2,
        },
        'Laboratório TI 4': {
            manhaAntes: laboratorioTI4BookedDaysPeriod1Turn1,
            manhaApos: laboratorioTI4BookedDaysPeriod1Turn2,
            tardeAntes: laboratorioTI4BookedDaysPeriod2Turn1,
            tardeApos: laboratorioTI4BookedDaysPeriod2Turn2,
        },
        'Laboratório de Hidráulica': {
            manhaAntes: laboratorioHidraulicaBookedDaysPeriod1Turn1,
            manhaApos: laboratorioHidraulicaBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioHidraulicaBookedDaysPeriod2Turn1,
            tardeApos: laboratorioHidraulicaBookedDaysPeriod2Turn2,
        },
        'Sala CLP': {
            manhaAntes: salaCLPBookedDaysPeriod1Turn1,
            manhaApos: salaCLPBookedDaysPeriod1Turn2,
            tardeAntes: salaCLPBookedDaysPeriod2Turn1,
            tardeApos: salaCLPBookedDaysPeriod2Turn2,
        },
        'Laboratório de Eletroeletrônica': {
            manhaAntes: laboratorioEletroeletronicaBookedDaysPeriod1Turn1,
            manhaApos: laboratorioEletroeletronicaBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioEletroeletronicaBookedDaysPeriod2Turn1,
            tardeApos: laboratorioEletroeletronicaBookedDaysPeriod2Turn2,
        },
        'Laboratório Máquina e Comandos': {
            manhaAntes: laboratorioMaquinaComandosBookedDaysPeriod1Turn1,
            manhaApos: laboratorioMaquinaComandosBookedDaysPeriod1Turn2,
            tardeAntes: laboratorioMaquinaComandosBookedDaysPeriod2Turn1,
            tardeApos: laboratorioMaquinaComandosBookedDaysPeriod2Turn2,
        },
        'Oficina Elétrica 1': {
            manhaAntes: oficinaEletrica1BookedDaysPeriod1Turn1,
            manhaApos: oficinaEletrica1BookedDaysPeriod1Turn2,
            tardeAntes: oficinaEletrica1BookedDaysPeriod2Turn1,
            tardeApos: oficinaEletrica1BookedDaysPeriod2Turn2,
        },
        'Oficina Elétrica 2': {
            manhaAntes: oficinaEletrica2BookedDaysPeriod1Turn1,
            manhaApos: oficinaEletrica2BookedDaysPeriod1Turn2,
            tardeAntes: oficinaEletrica2BookedDaysPeriod2Turn1,
            tardeApos: oficinaEletrica2BookedDaysPeriod2Turn2,
        },
    };
    

    // Obtém o parâmetro do nome do curso e define como valor do input
    const courseNameFromURL = getQueryParam('courseName');
    if (courseNameFromURL) {
        const courseInput = document.getElementById('course-name');
        courseInput.value = courseNameFromURL; // Define o nome do curso no input
    }

    // Agora o courseName será obtido do input com ID "course-name"
    const courseInput = document.getElementById('course-name');
    const courseName = courseInput.value;
    console.log('Course Name:', courseName); // Exibe o valor do input "course-name" no console

    // Ouvinte de evento para quando o valor do input "course-name" for alterado
    document.getElementById('course-name').addEventListener('input', function () {
        console.log('Valor do campo "course-name":', this.value);
    });

    if (courseName === 'Auditório') {
        console.log('O courseName realmente é igual a Auditório');
        bookedDaysPeriod1Turn1 = auditorioBookedDaysPeriod1Turn1; 
        bookedDaysPeriod1Turn2 = auditorioBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = auditorioBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = auditorioBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Biblioteca') {
        bookedDaysPeriod1Turn1 = bibliotecaBookedDaysPeriod1Turn1; 
        bookedDaysPeriod1Turn2 = bibliotecaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = bibliotecaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = bibliotecaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Oficina de Automobilística') {
        bookedDaysPeriod1Turn1 = oficinaAutomobilisticaBookedDaysPeriod1Turn1; 
        bookedDaysPeriod1Turn2 = oficinaAutomobilisticaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = oficinaAutomobilisticaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = oficinaAutomobilisticaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Oficina de Costura') {
        bookedDaysPeriod1Turn1 = oficinaCosturaBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = oficinaCosturaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = oficinaCosturaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = oficinaCosturaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório de Metrologia') {
        bookedDaysPeriod1Turn1 = laboratorioMetrologiaBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioMetrologiaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioMetrologiaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioMetrologiaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório de Automação Residencial') {
        bookedDaysPeriod1Turn1 = laboratorioAutomacaoResidencialBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioAutomacaoResidencialBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioAutomacaoResidencialBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioAutomacaoResidencialBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Sala de Solda') {
        bookedDaysPeriod1Turn1 = salaSoldaBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaSoldaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaSoldaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaSoldaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Oficina de Usinagem') {
        bookedDaysPeriod1Turn1 = oficinaUsinagemBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = oficinaUsinagemBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = oficinaUsinagemBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = oficinaUsinagemBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório de Redes - TI') {
        bookedDaysPeriod1Turn1 = laboratorioRedesTIBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioRedesTIBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioRedesTIBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioRedesTIBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    }  else if (courseName === 'Sala C1') {
        bookedDaysPeriod1Turn1 = salaC1BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaC1BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaC1BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaC1BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Sala C2') {
        bookedDaysPeriod1Turn1 = salaC2BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaC2BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaC2BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaC2BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Sala C3') {
        bookedDaysPeriod1Turn1 = salaC3BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaC3BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaC3BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaC3BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório de Administração') {
        bookedDaysPeriod1Turn1 = laboratorioAdministracaoBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioAdministracaoBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioAdministracaoBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioAdministracaoBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Sala C5') {
        bookedDaysPeriod1Turn1 = salaC5BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaC5BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaC5BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaC5BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório CAD') {
        bookedDaysPeriod1Turn1 = laboratorioCADBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioCADBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioCADBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioCADBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório CAM') {
        bookedDaysPeriod1Turn1 = laboratorioCAMBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioCAMBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioCAMBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioCAMBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório TI 1') {
        bookedDaysPeriod1Turn1 = laboratorioTI1BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioTI1BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioTI1BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioTI1BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório TI 2') {
        bookedDaysPeriod1Turn1 = laboratorioTI2BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioTI2BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioTI2BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioTI2BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório TI 3') {
        bookedDaysPeriod1Turn1 = laboratorioTI3BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioTI3BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioTI3BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioTI3BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório TI 4') {
        bookedDaysPeriod1Turn1 = laboratorioTI4BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioTI4BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioTI4BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioTI4BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório Hidráulica') {
        bookedDaysPeriod1Turn1 = laboratorioHidraulicaBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioHidraulicaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioHidraulicaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioHidraulicaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Sala CLP') {
        bookedDaysPeriod1Turn1 = salaCLPBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = salaCLPBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = salaCLPBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = salaCLPBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório Eletroeletrônica') {
        bookedDaysPeriod1Turn1 = laboratorioEletroeletronicaBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioEletroeletronicaBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioEletroeletronicaBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioEletroeletronicaBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Laboratório Máquina e Comandos') {
        bookedDaysPeriod1Turn1 = laboratorioMaquinaComandosBookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = laboratorioMaquinaComandosBookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = laboratorioMaquinaComandosBookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = laboratorioMaquinaComandosBookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Oficina Elétrica 1') {
        bookedDaysPeriod1Turn1 = oficinaEletrica1BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = oficinaEletrica1BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = oficinaEletrica1BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = oficinaEletrica1BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else if (courseName === 'Oficina Elétrica 2') {
        bookedDaysPeriod1Turn1 = oficinaEletrica2BookedDaysPeriod1Turn1;
        bookedDaysPeriod1Turn2 = oficinaEletrica2BookedDaysPeriod1Turn2;
        bookedDaysPeriod2Turn1 = oficinaEletrica2BookedDaysPeriod2Turn1;
        bookedDaysPeriod2Turn2 = oficinaEletrica2BookedDaysPeriod2Turn2;
        console.log('Valores de bookedDaysPeriod1Turn1 foram substituídos.');
    } else {
        console.log('Não é igual não, mano');
    }
  
    console.log(bookedDaysPeriod1Turn1)

    // Exemplo do objeto calendarios, ajustado para que as variáveis 'bookedDates' sejam alteradas dinamicamente
    const calendarios = {
        'manha-antes': {
            container: document.getElementById('calendario-manha-antes'),
            bookedDates: bookedDaysPeriod1Turn1,
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayManhaAntes'),
        },
        'manha-apos': {
            container: document.getElementById('calendario-manha-apos'),
            bookedDates: bookedDaysPeriod1Turn2,
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayManhaApos'),
        },
        'tarde-antes': {
            container: document.getElementById('calendario-tarde-antes'),
            bookedDates: bookedDaysPeriod2Turn1,
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayTardeAntes'),
        },
        'tarde-apos': {
            container: document.getElementById('calendario-tarde-apos'),
            bookedDates: bookedDaysPeriod2Turn2,
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayTardeApos'),
        },
    };



    

    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    const monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    function isLeapYear(year) {
        return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    }

    function createCalendar(calendarObj) {
        const calendar = calendarObj.container.querySelector('.calendar');
        const month = calendarObj.currentMonth;
        const year = calendarObj.currentYear;
        const daysInMonth = month === 1 && isLeapYear(year) ? 29 : monthDays[month];
        const today = new Date();
    
        calendarObj.monthDisplay.textContent = `${monthNames[month]} ${year}`;
        calendar.innerHTML = ''; // Limpa o calendário
    
        const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
        weekDays.forEach(day => {
            const weekDayElement = document.createElement('div');
            weekDayElement.classList.add('day');
            weekDayElement.textContent = day;
            weekDayElement.style.fontWeight = 'bold';
            calendar.appendChild(weekDayElement);
        });
    
        const firstDay = new Date(year, month, 1).getDay();
    
        for (let i = 0; i < firstDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.classList.add('day');
            calendar.appendChild(emptyCell);
        }
    
        for (let i = 1; i <= daysInMonth; i++) {
            const day = document.createElement('div');
            day.classList.add('day');
            day.textContent = i;
    
            const selectedDate = new Date(year, month, i);
            const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    
            // Verificando se a data está reservada
            if (calendarObj.bookedDates.includes(formattedDate)) {
                day.classList.add('booked');  // Adiciona a classe para destacar a data
                day.onclick = () => alert('Data já reservada!');
            } else if (selectedDate < today) {
                day.classList.add('booked');
                day.onclick = () => alert('Essa data já passou!');
            } else {
                day.onclick = () => handleDayClick(calendarObj, day, i, year, month);
            }
    
            calendar.appendChild(day);
        }
    }

    // Criação de todos os calendários
    for (const key in calendarios) {
        createCalendar(calendarios[key]);
    }

    function reloadCalendar() {
        for (const key in calendarios) {
            // Atualizar o array bookedDates com as novas reservas, pode ser feito via AJAX ou diretamente ao fazer uma reserva
            calendarios[key].bookedDates = getUpdatedBookedDates(key); // Assume que você tenha uma função que retorna as datas reservadas mais recentes
    
            // Recriar o calendário com as novas datas
            createCalendar(calendarios[key]);
        }
    }
    
    // Exemplo de uma função que pode obter as datas reservadas mais recentes
    // Essa função pode ser adaptada para buscar os dados do servidor via AJAX ou de onde for necessário
    function getUpdatedBookedDates(calendarKey) {
        // Simulação de um novo conjunto de datas reservadas
        // Aqui você deve implementar uma chamada AJAX para buscar as datas reservadas atualizadas no servidor, ou manter um array atualizado
        switch(calendarKey) {
            case 'manha-antes':
                return bookedDaysPeriod1Turn1;
            case 'manha-apos':
                return bookedDaysPeriod1Turn2;
            case 'tarde-antes':
                return bookedDaysPeriod2Turn1;
            case 'tarde-apos':
                return bookedDaysPeriod2Turn2;
            default:
                return [];
        }
    }

    
    // Exemplo de como você pode chamar a função reloadCalendar após uma reserva ser realizada
    // Por exemplo, após um formulário de reserva ser enviado via AJAX e as novas reservas forem gravadas no banco de dados, você pode chamar essa função
    
    // reloadCalendar();  // Quando você quiser recarregar os calendários
    


    function handleDayClick(calendarObj, day, dayNumber, year, month) {
        const selectedDate = new Date(year, month, dayNumber);
        if (selectedDate < new Date()) {
            alert('Essa data já passou!');
        } else if (calendarObj.bookedDates.includes(dayNumber)) {
            alert('Data já reservada!');
        } else {
            // Lógica para adicionar/remover dias da seleção
            if (!calendarObj.selectedDays[`${year}-${month}`]) {
                calendarObj.selectedDays[`${year}-${month}`] = [];
            }

            if (calendarObj.selectedDays[`${year}-${month}`].includes(dayNumber)) {
                calendarObj.selectedDays[`${year}-${month}`] = calendarObj.selectedDays[`${year}-${month}`].filter(d => d !== dayNumber);
                day.classList.remove('selected');
            } else {
                calendarObj.selectedDays[`${year}-${month}`].push(dayNumber);
                day.classList.add('selected');
            }

            showSelectedDates(calendarObj);
        }
    }

    function showSelectedDates(calendarObj) {
        const selectedDates = [];
        Object.keys(calendarObj.selectedDays).forEach(key => {
            const monthDays = calendarObj.selectedDays[key];
            monthDays.forEach(day => {
                const [year, month] = key.split('-');
                selectedDates.push(`${year}-${String(Number(month) + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
            });
        });
        
        // Atualiza o campo oculto com as datas selecionadas
        const selectedDatesField = document.getElementById('selectedDates');
        selectedDatesField.value = selectedDates.join(","); // Junta as datas em uma string separada por vírgula
    
        alert("Datas selecionadas: " + selectedDates.join(", "));
    }

    function toggleCalendars() {
        const selectedTurn = document.querySelector('input[name="turn"]:checked')?.value;
        const selectedPeriod = document.querySelector('input[name="period"]:checked')?.value;
    
        console.log('Selected Turn:', selectedTurn);
        console.log('Selected Period:', selectedPeriod);
    
        Object.values(calendarios).forEach(cal => cal.container.style.display = 'none');
    
        if (selectedTurn === 'antes' && selectedPeriod === 'antes') {
            calendarios['manha-antes'].container.style.display = 'block';
            console.log('Displaying: Manhã Antes');
            createCalendar(calendarios['manha-antes']);
        } else if (selectedTurn === 'antes' && selectedPeriod === 'após') {
            calendarios['manha-apos'].container.style.display = 'block';
            console.log('Displaying: Manhã Após');
            createCalendar(calendarios['manha-apos']);
        } else if (selectedTurn === 'após' && selectedPeriod === 'antes') {
            calendarios['tarde-antes'].container.style.display = 'block';
            console.log('Displaying: Tarde Antes');
            createCalendar(calendarios['tarde-antes']);
        } else if (selectedTurn === 'após' && selectedPeriod === 'após') {
            calendarios['tarde-apos'].container.style.display = 'block';
            console.log('Displaying: Tarde Após');
            createCalendar(calendarios['tarde-apos']);
        }
    
        const calendarPlaceholder = document.getElementById('calendar-placeholder');
        if (selectedTurn && selectedPeriod) {
            calendarPlaceholder.style.display = 'none'; // Esconde o H2
            console.log('Calendar Placeholder hidden.');
        } else {
            calendarPlaceholder.style.display = 'block'; // Mostra o H2 se nada estiver selecionado
            console.log('Calendar Placeholder displayed.');
        }
    }
    

    turnRadios.forEach(radio => {
        radio.addEventListener('change', toggleCalendars);
    });
    periodRadios.forEach(radio => {
        radio.addEventListener('change', toggleCalendars);
    });

    // Funções para navegação entre meses
    document.getElementById('prevMonthManhaAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-antes'], -1);
    });
    document.getElementById('nextMonthManhaAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-antes'], 1);
    });

    document.getElementById('prevMonthManhaApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-apos'], -1);
    });
    document.getElementById('nextMonthManhaApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-apos'], 1);
    });

    document.getElementById('prevMonthTardeAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-antes'], -1);
    });
    document.getElementById('nextMonthTardeAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-antes'], 1);
    });

    document.getElementById('prevMonthTardeApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-apos'], -1);
    });
    document.getElementById('nextMonthTardeApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-apos'], 1);
    });

        // Função para alterar o mês
        function changeMonth(calendarObj, direction) {
            calendarObj.currentMonth += direction;
            if (calendarObj.currentMonth < 0) {
                calendarObj.currentMonth = 11;
                calendarObj.currentYear -= 1;
            } else if (calendarObj.currentMonth > 11) {
                calendarObj.currentMonth = 0;
                calendarObj.currentYear += 1;
            }
            createCalendar(calendarObj);
        }

// Validação do Formulário
document.getElementById('yourFormId').addEventListener('submit', function(event) {
    const selectedDatesField = document.getElementById('selectedDates');
    const turnoField = document.querySelector('input[name="turn"]:checked');  // Seleciona o botão de rádio do turno selecionado
    const periodoField = document.querySelector('input[name="period"]:checked'); // Seleciona o botão de rádio do período selecionado

    if (selectedDatesField.value.trim() === "") {
        alert("Por favor, selecione ao menos uma data antes de enviar o formulário.");
        event.preventDefault();
        createCalendar(calendarObj);
    } else {
        // Mapeando os valores para descrições legíveis
        const turno = turnoField ? (turnoField.value === 'antes' ? 'Manhã' : 'Tarde') : 'Nenhum';
        const periodo = periodoField ? (periodoField.value === 'antes' ? 'Antes do intervalo' : 'Após o intervalo') : 'Nenhum';
        const formattedDates = selectedDatesField.value.split(',').map(date => date.trim()).join(', ');

        alert("Reserva feita com sucesso!\n\n" + 
              "Datas selecionadas: " + formattedDates + "\n" + 
              "Turno: " + turno + "\n" + 
              "Período: " + periodo);
        location.reload();
        createCalendar(calendarObj);
        getUpdatedBookedDates();
        // Permite o envio do formulário para o backend
        setTimeout(() => {
            location.reload(); // Recarrega a página após o envio
        }, 50); // Aguarda um breve momento para garantir que o envio seja processado
    }
});



    // Inicializa o calendário do mês atual
    toggleCalendars();
    reloadCalendar();
    getUpdatedBookedDates();
    createCalendar(calendarObj);
});
