document.addEventListener('DOMContentLoaded', () => {
    const periodRadios = document.querySelectorAll('input[name="period"]');
    const turnRadios = document.querySelectorAll('input[name="turn"]');
    console.log("Lista de datas reservadas:", allBookedDays);

    const calendarios = {
        'manha-antes': {
            container: document.getElementById('calendario-manha-antes'),
            bookedDates: allBookedDays,
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayManhaAntes')
        },
        'manha-apos': {
            container: document.getElementById('calendario-manha-apos'),
            bookedDates: [],
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayManhaApos')
        },
        'tarde-antes': {
            container: document.getElementById('calendario-tarde-antes'),
            bookedDates: [],
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayTardeAntes')
        },
        'tarde-apos': {
            container: document.getElementById('calendario-tarde-apos'),
            bookedDates: [],
            selectedDays: {},
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            monthDisplay: document.getElementById('monthDisplayTardeApos')
        }
    };

    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    const monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    function isLeapYear(year) {
        return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    }

    function createCalendar(calendarObj) {
        const calendar = calendarObj.container.querySelector('.calendar');
        const month = calendarObj.currentMonth;
        const year = calendarObj.currentYear;
        const daysInMonth = month === 1 && isLeapYear(year) ? 29 : monthDays[month];
        const today = new Date();
    
        calendarObj.monthDisplay.textContent = `${monthNames[month]} ${year}`;
        calendar.innerHTML = ''; // Limpa o calendário
    
        const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
        weekDays.forEach(day => {
            const weekDayElement = document.createElement('div');
            weekDayElement.classList.add('day');
            weekDayElement.textContent = day;
            weekDayElement.style.fontWeight = 'bold';
            calendar.appendChild(weekDayElement);
        });
    
        const firstDay = new Date(year, month, 1).getDay();
    
        for (let i = 0; i < firstDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.classList.add('day');
            calendar.appendChild(emptyCell);
        }
    
        for (let i = 1; i <= daysInMonth; i++) {
            const day = document.createElement('div');
            day.classList.add('day');
            day.textContent = i;
    
            const selectedDate = new Date(year, month, i);
            const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    
            // Verificando se a data está reservada
            if (calendarObj.bookedDates.includes(formattedDate)) {
                day.classList.add('booked');  // Adiciona a classe para destacar a data
                day.onclick = () => alert('Data já reservada!');
            } else if (selectedDate < today) {
                day.classList.add('booked');
                day.onclick = () => alert('Essa data já passou!');
            } else {
                day.onclick = () => handleDayClick(calendarObj, day, i, year, month);
            }
    
            calendar.appendChild(day);
        }
    }

    // Criação de todos os calendários
    for (const key in calendarios) {
        createCalendar(calendarios[key]);
    }


    function handleDayClick(calendarObj, day, dayNumber, year, month) {
        const selectedDate = new Date(year, month, dayNumber);
        if (selectedDate < new Date()) {
            alert('Essa data já passou!');
        } else if (calendarObj.bookedDates.includes(dayNumber)) {
            alert('Data já reservada!');
        } else {
            // Lógica para adicionar/remover dias da seleção
            if (!calendarObj.selectedDays[`${year}-${month}`]) {
                calendarObj.selectedDays[`${year}-${month}`] = [];
            }

            if (calendarObj.selectedDays[`${year}-${month}`].includes(dayNumber)) {
                calendarObj.selectedDays[`${year}-${month}`] = calendarObj.selectedDays[`${year}-${month}`].filter(d => d !== dayNumber);
                day.classList.remove('selected');
            } else {
                calendarObj.selectedDays[`${year}-${month}`].push(dayNumber);
                day.classList.add('selected');
            }

            showSelectedDates(calendarObj);
        }
    }

    function showSelectedDates(calendarObj) {
        const selectedDates = [];
        Object.keys(calendarObj.selectedDays).forEach(key => {
            const monthDays = calendarObj.selectedDays[key];
            monthDays.forEach(day => {
                const [year, month] = key.split('-');
                selectedDates.push(`${year}-${String(Number(month) + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
            });
        });
        
        // Atualiza o campo oculto com as datas selecionadas
        const selectedDatesField = document.getElementById('selectedDates');
        selectedDatesField.value = selectedDates.join(","); // Junta as datas em uma string separada por vírgula
    
        alert("Datas selecionadas: " + selectedDates.join(", "));
    }

    function toggleCalendars() {
        const selectedTurn = document.querySelector('input[name="turn"]:checked')?.value;
        const selectedPeriod = document.querySelector('input[name="period"]:checked')?.value;

        Object.values(calendarios).forEach(cal => cal.container.style.display = 'none');

        if (selectedTurn === 'antes' && selectedPeriod === 'antes') {
            calendarios['manha-antes'].container.style.display = 'block';
            createCalendar(calendarios['manha-antes']);
        } else if (selectedTurn === 'antes' && selectedPeriod === 'após') {
            calendarios['manha-apos'].container.style.display = 'block';
            createCalendar(calendarios['manha-apos']);
        } else if (selectedTurn === 'após' && selectedPeriod === 'antes') {
            calendarios['tarde-antes'].container.style.display = 'block';
            createCalendar(calendarios['tarde-antes']);
        } else if (selectedTurn === 'após' && selectedPeriod === 'após') {
            calendarios['tarde-apos'].container.style.display = 'block';
            createCalendar(calendarios['tarde-apos']);
        }

        const calendarPlaceholder = document.getElementById('calendar-placeholder');
        if (selectedTurn && selectedPeriod) {
            calendarPlaceholder.style.display = 'none'; // Esconde o H2
        } else {
            calendarPlaceholder.style.display = 'block'; // Mostra o H2 se nada estiver selecionado
        }
    }

    turnRadios.forEach(radio => {
        radio.addEventListener('change', toggleCalendars);
    });
    periodRadios.forEach(radio => {
        radio.addEventListener('change', toggleCalendars);
    });

    // Funções para navegação entre meses
    document.getElementById('prevMonthManhaAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-antes'], -1);
    });
    document.getElementById('nextMonthManhaAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-antes'], 1);
    });

    document.getElementById('prevMonthManhaApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-apos'], -1);
    });
    document.getElementById('nextMonthManhaApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['manha-apos'], 1);
    });

    document.getElementById('prevMonthTardeAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-antes'], -1);
    });
    document.getElementById('nextMonthTardeAntes').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-antes'], 1);
    });

    document.getElementById('prevMonthTardeApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-apos'], -1);
    });
    document.getElementById('nextMonthTardeApos').addEventListener('click', (event) => {
        event.preventDefault(); // Impede o comportamento padrão do botão
        changeMonth(calendarios['tarde-apos'], 1);
    });

        // Função para alterar o mês
        function changeMonth(calendarObj, direction) {
            calendarObj.currentMonth += direction;
            if (calendarObj.currentMonth < 0) {
                calendarObj.currentMonth = 11;
                calendarObj.currentYear -= 1;
            } else if (calendarObj.currentMonth > 11) {
                calendarObj.currentMonth = 0;
                calendarObj.currentYear += 1;
            }
            createCalendar(calendarObj);
        }

// Validação do Formulário
document.getElementById('yourFormId').addEventListener('submit', function(event) {
    const selectedDatesField = document.getElementById('selectedDates');
    const turnoField = document.querySelector('input[name="turn"]:checked');  // Seleciona o botão de rádio do turno selecionado
    const periodoField = document.querySelector('input[name="period"]:checked'); // Seleciona o botão de rádio do período selecionado

    if (selectedDatesField.value.trim() === "") {
        alert("Por favor, selecione ao menos uma data antes de enviar o formulário.");
        event.preventDefault();
    } else {
        // Mapeando os valores para descrições legíveis
        const turno = turnoField ? (turnoField.value === 'antes' ? 'Manhã' : 'Tarde') : 'Nenhum';
        const periodo = periodoField ? (periodoField.value === 'antes' ? 'Antes do intervalo' : 'Após o intervalo') : 'Nenhum';
        const formattedDates = selectedDatesField.value.split(',').map(date => date.trim()).join(', ');

        alert("Reserva feita com sucesso!\n\n" + 
              "Datas selecionadas: " + formattedDates + "\n" + 
              "Turno: " + turno + "\n" + 
              "Período: " + periodo + "\n\n" +
                "A página será recarregada se você precisar fazer uma nova reserva.");
    }
});


    // Inicializa o calendário do mês atual
    toggleCalendars();
});
