import smtplib

try:
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login('atlasreservadesala@gmail.com', 'atlas!1234')  # Substitua pelo seu e-mail e senha
    print("Login bem-sucedido!")
except smtplib.SMTPAuthenticationError as e:
    print("Erro de autenticação:", e)
finally:
    server.quit()
